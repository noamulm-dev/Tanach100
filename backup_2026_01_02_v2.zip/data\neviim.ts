
export const NEVIIM_DATA = {};
