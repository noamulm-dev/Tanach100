
import React from 'react';
import { X, Grid2X2 } from 'lucide-react';

interface Props {
    onClose: () => void;
    isDarkMode: boolean;
}

const MatrixVisualizer2: React.FC<Props> = ({ onClose, isDarkMode }) => {
    return (
        <div className="relative w-full h-full flex flex-col overflow-hidden animate-in fade-in duration-500">
            {/* Header */}
            <div className={`shrink-0 h-[40px] border-b flex items-center justify-between px-4 backdrop-blur-md z-20 ${isDarkMode ? 'bg-slate-900/50 border-white/5' : 'bg-slate-100/50 border-black/5'}`}>
                <div className="flex items-center gap-2 text-slate-500">
                    <Grid2X2 size={16} />
                    <span className="text-xs font-bold uppercase">מטריצה 2</span>
                </div>
                
                <button 
                    onClick={onClose} 
                    className="p-1.5 bg-rose-500 text-white rounded-md hover:bg-rose-600 transition-colors shadow-sm"
                >
                    <X size={14} strokeWidth={3} />
                </button>
            </div>

            {/* Empty Content Area */}
            <div className={`flex-1 flex items-center justify-center ${isDarkMode ? 'bg-slate-950' : 'bg-slate-50'}`}>
                <p className="opacity-30 font-bold text-lg">תוכן מטריצה 2 (ריק)</p>
            </div>
        </div>
    );
};

export default MatrixVisualizer2;
