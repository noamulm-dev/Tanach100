
import React, { useMemo, useEffect, useRef } from 'react';
import '../types'; // Registers global JSX intrinsics for Three.js
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import type { CharData, BookType } from '../types';
import { torahTexts } from '../data/torahTexts';

// --- TEXTURE CACHE ---
const textureCache: Record<string, THREE.CanvasTexture> = {};

// --- SHARED ASSETS ---
const sharedBoxGeometry = new THREE.BoxGeometry(0.96, 0.96, 0.96);
const sharedBoxEdgesGeometry = new THREE.EdgesGeometry(sharedBoxGeometry);

// Materials
const defaultCubeMaterial = new THREE.MeshPhysicalMaterial({
    color: '#ffffff',
    transparent: true,
    opacity: 0.0, // Invisible
    depthWrite: false, 
    side: THREE.FrontSide
});

// Faint edges for structure visibility
const faintEdgeMaterial = new THREE.LineBasicMaterial({
    color: '#888888',
    transparent: true,
    opacity: 0.15,
    depthWrite: false
});

// Vibrant highlight for found word cubes
const foundCubeMaterial = new THREE.MeshPhysicalMaterial({
    color: '#ffffff', // White glow for the cube box
    transparent: true,
    opacity: 0.12, 
    transmission: 0.4, 
    roughness: 0.05,
    metalness: 0.1,
    emissive: '#ffffff', 
    emissiveIntensity: 0.15, 
    depthWrite: false,
    side: THREE.FrontSide
});

// Yellow Glow for Selected Board
const highlightCubeMaterial = new THREE.MeshPhysicalMaterial({
    color: '#ffff00', 
    transparent: true,
    opacity: 0.01, 
    transmission: 0.1,
    roughness: 0.1,
    metalness: 0.1,
    emissive: '#ffff00',
    emissiveIntensity: 0.05,
    depthWrite: false,
    side: THREE.FrontSide
});

// --- CUSTOM ORTHO BILLBOARD ---
const OrthoBillboard: React.FC<{ children: React.ReactNode; position?: [number, number, number] }> = ({ children, position }) => {
    const groupRef = useRef<THREE.Group>(null);
    useFrame(({ camera }) => {
        if (groupRef.current) {
            groupRef.current.quaternion.copy(camera.quaternion);
        }
    });
    return <group ref={groupRef} position={position}>{children}</group>;
};

// Flat 2D Text Component
const SkipsFlatChar: React.FC<{
  char: string;
  textColor: string;
  fontLoaded: boolean;
  selectedFont: string;
  isBold: boolean;
  opacity?: number;
  isFound?: boolean;
}> = ({ char, textColor, fontLoaded, selectedFont, isBold, opacity = 1.0, isFound = false }) => {
  
  const cacheKey = `skips-text-v3-${char}-${fontLoaded}-${selectedFont}-${isBold}-${textColor}-${isFound}-${opacity}-res512`;
  
  const texture = useMemo(() => {
    if (textureCache[cacheKey]) return textureCache[cacheKey];

    // High resolution canvas
    const size = 512;
    const center = size / 2;
    
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, size, size);

      // Force bold for found words with high impact
      const weightPrefix = (isBold || isFound) ? 'bold' : 'normal';
      // Scaled font size (was 96px for 128 canvas -> approx 384px for 512 canvas)
      ctx.font = `${weightPrefix} 380px "${selectedFont}", "Stam", serif`; 
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.direction = 'rtl';

      // Enhanced contrast shadow
      ctx.shadowColor = isFound ? 'rgba(0, 0, 0, 1.0)' : 'rgba(0, 0, 0, 0.8)';
      ctx.shadowBlur = isFound ? 80 : 24; // Scaled shadow blur
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;

      // Heavy stroke for maximum visibility against any background
      ctx.strokeStyle = isFound ? 'rgba(0,0,0,1.0)' : 'rgba(0,0,0,0.9)';
      ctx.lineWidth = isFound ? 32 : 20; // Scaled line width
      ctx.strokeText(char, center, center);

      // Extra bright white inner glow for the found text
      if (isFound) {
          ctx.shadowColor = 'rgba(255, 255, 255, 1.0)';
          ctx.shadowBlur = 96;
      }

      // Draw Main Text
      ctx.fillStyle = textColor;
      ctx.fillText(char, center, center);
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 4;
    textureCache[cacheKey] = tex;
    return tex;
  }, [char, fontLoaded, selectedFont, isBold, textColor, isFound, opacity]);

  return (
    <mesh>
        <planeGeometry args={[0.96, 0.96]} />
        <meshStandardMaterial 
            map={texture}
            transparent={true}
            opacity={opacity}
            alphaTest={0.05} // Slightly higher alpha test to clean up edges
            side={THREE.DoubleSide} 
            roughness={0.5}
            metalness={0.1}
        />
    </mesh>
  );
};

// --- CHAR COMPONENT ---
const SkipsCharWrapper: React.FC<{
  charData: CharData;
  position: [number, number, number];
  fontLoaded: boolean;
  selectedFont: string;
  isBold: boolean;
  opacity?: number;
  isHighlightedLayer?: boolean;
  isFoundWord?: boolean;
}> = ({ charData, position, fontLoaded, selectedFont, isBold, opacity = 1.0, isHighlightedLayer, isFoundWord }) => {
    
    const groupRef = useRef<THREE.Group>(null);

    // Pulse effect for found words
    useFrame((state) => {
        if (isFoundWord && groupRef.current) {
            const pulse = 1.0 + Math.sin(state.clock.elapsedTime * 4) * 0.04;
            groupRef.current.scale.set(pulse, pulse, pulse);
        } else if (groupRef.current) {
            groupRef.current.scale.set(1, 1, 1);
        }
    });

    // Letter Colors
    let textColor = '#ffffff'; 
    let cubeMat = null;

    if (isFoundWord) {
        textColor = '#ff0000'; // Pure Strong Red
        cubeMat = foundCubeMaterial; 
    } else if (isHighlightedLayer) {
        textColor = '#fbbf24'; // Amber Yellow for active layer
        cubeMat = highlightCubeMaterial;
    }

    // UPDATED Visibility logic for maximum clarity:
    // Found word: 1.0
    // Highlighted layer letter: 0.9 (Very visible)
    // Rest of the matrix: 0.25 (Visible structure, but transparent enough)
    const effectiveTextOpacity = isFoundWord ? 1.0 : (isHighlightedLayer ? 0.9 : 0.25);

    return (
        <group position={position} ref={groupRef}>
             {/* Background Cube - Show only for highlighted or found words */}
             {(isFoundWord || isHighlightedLayer) && cubeMat && <mesh geometry={sharedBoxGeometry} material={cubeMat} />}

             {/* Faint edges for ALL cubes to define 216-block structure */}
             {!isFoundWord && (
                 <lineSegments geometry={sharedBoxEdgesGeometry} material={faintEdgeMaterial} />
             )}

             {/* Strong Highlight Outline for Found Words */}
             {isFoundWord && (
                 <lineSegments geometry={sharedBoxEdgesGeometry}>
                     <lineBasicMaterial color="#ffffff" transparent opacity={0.9} linewidth={2} />
                 </lineSegments>
             )}

             {/* Text Billboard */}
             <OrthoBillboard>
                 <SkipsFlatChar 
                    char={charData.char}
                    textColor={textColor}
                    fontLoaded={fontLoaded}
                    selectedFont={selectedFont}
                    isBold={isBold}
                    opacity={effectiveTextOpacity}
                    isFound={isFoundWord}
               />
             </OrthoBillboard>
        </group>
    )
}

// --- SKIPS VERSE LAYER ---
const SkipsVerseLayer: React.FC<{ 
  chars: CharData[]; 
  layerIndex: number; 
  verticalSpread: number;
  fontLoaded: boolean;
  selectedFont: string;
  isBold: boolean;
  opacity?: number;
  isHighlightedLayer: boolean;
  globalStartIndex: number;
  foundIndices: Set<number>;
  rows: number;
  cols: number;
}> = React.memo(({ chars, layerIndex, verticalSpread, fontLoaded, selectedFont, isBold, opacity, isHighlightedLayer, globalStartIndex, foundIndices, rows, cols }) => {
  const numRows = rows;
  const numCols = cols;
  const centerOffsetY = (numRows - 1) / 2;
  const centerOffsetX = (numCols - 1) / 2;

  return (
    <group>
      {chars.map((charData, i) => {
        if (i >= numRows * numCols) return null;
        
        const globalIndex = globalStartIndex + i;
        const row = Math.floor(i / numCols);
        const col = i % numCols;
        
        const y = (centerOffsetY - row) * verticalSpread;
        const x = centerOffsetX - col; 
        
        const isFound = foundIndices.has(globalIndex);

        return (
             <SkipsCharWrapper
                key={`${layerIndex}-${i}`}
                charData={charData}
                position={[x, y, 0]} 
                fontLoaded={fontLoaded}
                selectedFont={selectedFont}
                isBold={isBold}
                opacity={opacity}
                isHighlightedLayer={isHighlightedLayer}
                isFoundWord={isFound}
             />
        )
      })}
    </group>
  );
});

const WORDS_TO_FIND = ["תורה", "יהוה", "הרות", "הוהי"]; 

const getCoords = (i: number, cols: number, rows: number, layers: number) => {
    const layer = Math.floor(i / (cols * rows));
    const rem = i % (cols * rows);
    const row = Math.floor(rem / cols);
    const col = rem % cols;
    return { x: col, y: row, z: layer };
};

const getIndex = (x: number, y: number, z: number, cols: number, rows: number, layers: number) => {
    if (x < 0 || x >= cols || y < 0 || y >= rows || z < 0 || z >= layers) return -1;
    return z * (cols * rows) + y * cols + x;
};

// --- MAIN SKIPS SYSTEM COMPONENT ---
export const SkipsSystem: React.FC<{
    highlightLayer: number;
    gapSize: number;
    verticalSpread: number;
    fontLoaded: boolean;
    selectedFont: string;
    isBold: boolean;
    splitState: number; 
    textOffset?: number;
    skipsBook?: BookType;
    skipsDims?: { cols: number; rows: number; layers: number; };
    onWordFound?: (found: boolean) => void;
}> = React.memo(({ highlightLayer, gapSize, verticalSpread, fontLoaded, selectedFont, isBold, splitState, textOffset = 0, skipsBook = 'genesis', skipsDims, onWordFound }) => {
    
    const { cols, rows, layers } = skipsDims || { cols: 7, rows: 7, layers: 7 };
    const layerSize = cols * rows;
    const centerOffsetZ = (layers - 1) / 2; 

    const displayData = useMemo(() => {
        const textToUse = (torahTexts && torahTexts[skipsBook || 'genesis']) || ""; 
        if (!textToUse) return [];
        
        const gridVolume = cols * rows * layers;
        const slicedChars = textToUse.slice(textOffset, textOffset + gridVolume).split('');
        
        const baseData: CharData[] = slicedChars.map(c => ({
            char: c,
            originalChar: c,
            color: '#ffffff',
            customScale: 1.0
        }));

        if (baseData.length < gridVolume) {
             const needed = gridVolume - baseData.length;
             const padding = Array(needed).fill({ char: '', originalChar: '', color: '#ffffff' });
             return [...baseData, ...padding];
        }
        
        return baseData;
    }, [textOffset, skipsBook, cols, rows, layers]);
    
    const foundIndices = useMemo(() => {
        const found = new Set<number>();
        const data = displayData; 
        if (!data || data.length === 0) return found;

        const directions: {x: number, y: number, z: number}[] = [];
        for(let dz = -1; dz <= 1; dz++) {
            for(let dy = -1; dy <= 1; dy++) {
                for(let dx = -1; dx <= 1; dx++) {
                    if (dx === 0 && dy === 0 && dz === 0) continue;
                    directions.push({x: dx, y: dy, z: dz});
                }
            }
        }

        WORDS_TO_FIND.forEach(word => {
            const wordLen = word.length;
            const maxIdx = cols * rows * layers;
            
            for (let i = 0; i < Math.min(data.length, maxIdx); i++) {
                if (data[i].char !== word[0]) continue;
                const startCoords = getCoords(i, cols, rows, layers);
                for (const dir of directions) {
                    let match = true;
                    const pathIndices = [i];
                    for (let k = 1; k < wordLen; k++) {
                        const nextX = startCoords.x + (dir.x * k);
                        const nextY = startCoords.y + (dir.y * k);
                        const nextZ = startCoords.z + (dir.z * k);
                        const nextIdx = getIndex(nextX, nextY, nextZ, cols, rows, layers);
                        if (nextIdx === -1 || !data[nextIdx] || data[nextIdx].char !== word[k]) {
                            match = false;
                            break;
                        }
                        pathIndices.push(nextIdx);
                    }
                    if (match) {
                        pathIndices.forEach(idx => found.add(idx));
                    }
                }
            }
        });
        return found;
    }, [cols, rows, layers, displayData]); 

    useEffect(() => {
        if (onWordFound) {
            onWordFound(foundIndices.size > 0);
        }
    }, [foundIndices, onWordFound]);

    return (
        <group>
            {Array.from({length: layers}).map((_, i) => {
                 const layerIndex = i;
                 const startIdx = layerIndex * layerSize;
                 const layerChars = displayData.slice(startIdx, startIdx + layerSize);
                 
                 const zPos = (-centerOffsetZ + layerIndex) * gapSize;
                 
                 const isHighlighted = highlightLayer === (layerIndex + 1);
                 
                 // Note: Opacity prop here is for layer containers if needed, 
                 // but individual character opacity is controlled by SkipsCharWrapper
                 const opacity = isHighlighted ? 1.0 : 0.002; 

                 return (
                    <group key={layerIndex} position={[0, 0, zPos]}>
                        <SkipsVerseLayer 
                            chars={layerChars} 
                            layerIndex={layerIndex} 
                            verticalSpread={verticalSpread} 
                            fontLoaded={fontLoaded}
                            selectedFont={selectedFont}
                            isBold={isBold}
                            opacity={opacity}
                            isHighlightedLayer={isHighlighted}
                            globalStartIndex={startIdx}
                            foundIndices={foundIndices}
                            rows={rows}
                            cols={cols}
                        />
                    </group>
                 );
            })}
        </group>
    );
});
