
import React, { useMemo } from 'react';
import * as THREE from 'three';

const SphereHalf: React.FC<{ side: 'left' | 'right'; color: string; }> = ({ side, color }) => {
    // Opaque and Shiny Material (Not Glass)
    const material = useMemo(() => new THREE.MeshPhysicalMaterial({
        color: color,
        roughness: 0.15,      // Smooth surface for shine
        metalness: 0.4,       // Metallic look
        transparent: false,   // Solid/Opaque
        opacity: 1.0,
        side: THREE.FrontSide,
        clearcoat: 1.0,       // Car-paint like finish
        clearcoatRoughness: 0.1,
        envMapIntensity: 1.5,
        transmission: 0       // No glass effect
    }), [color]);
    
    // Black Cap Material for the cut face
    const capMaterial = useMemo(() => new THREE.MeshBasicMaterial({
        color: '#000000',
        side: THREE.DoubleSide
    }), []);

    const isLeft = side === 'left';
    // Position offset to align the split face with the center of the gap
    const xPos = isLeft ? 1.5 : -1.5;
    
    // Rotation: Align the flat part of the hemisphere to the split plane.
    const rotation: [number, number, number] = [0, isLeft ? -Math.PI / 2 : Math.PI / 2, 0];

    return (
        <group position={[xPos, 0, 0]}>
             <group rotation={rotation}>
                 {/* Outer Shell */}
                 <mesh castShadow receiveShadow>
                    <sphereGeometry args={[3.0, 64, 64, 0, Math.PI]} />
                    <primitive object={material} attach="material" />
                </mesh>
                
                {/* Inner Black Cap (Solid Cut Appearance) */}
                <mesh>
                    {/* CircleGeometry created on XY plane. No rotation needed relative to sphere sector as Z=0 is the cut plane. */}
                    <circleGeometry args={[3.0, 64]} />
                    <primitive object={capMaterial} attach="material" />
                </mesh>
             </group>
        </group>
    )
}

export default SphereHalf;
