
import React, { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { CharTexturePlane } from './CharTexturePlane';
import '../types';

// Helper to get distinct colors for the two tetrahedrons based on the primary color
const getStellaColors = (color: string): [string, string] => {
    // If transparent (index 5 usually), return specific pair
    if (color === '#ffffff') return ['#ffffff', '#3b82f6'];

    const base = new THREE.Color(color);
    const hex = '#' + base.getHexString();
    
    // Specific overrides for app palette to ensure nice contrast
    switch(hex) {
        case '#eab308': return ['#eab308', '#172554']; // Gold & Dark Blue (Classic Merkaba)
        case '#38bdf8': return ['#38bdf8', '#eab308']; // Light Blue & Gold
        case '#0ea5e9': return ['#0ea5e9', '#eab308']; // Sky Blue & Gold
        case '#8b5cf6': return ['#8b5cf6', '#f59e0b']; // Purple & Amber
        case '#e0e0e0': return ['#e0e0e0', '#3b82f6']; // Gray & Blue
    }
    
    // Fallback: Use a darker shade or complementary if not in palette
    const sec = base.clone().offsetHSL(0.5, 0, -0.2); 
    return [hex, '#' + sec.getHexString()];
};

export const PerfectStella: React.FC<{ color: string; isTransparent: boolean; showHalfStella?: boolean; }> = ({ color, isTransparent, showHalfStella }) => {
    const radius = 5.196; // Exactly fits a 6x6x6 cube (3 * sqrt(3))
    
    const [c1, c2] = useMemo(() => getStellaColors(color), [color]);

    const material1 = useMemo(() => new THREE.MeshPhysicalMaterial({
        color: c1,
        roughness: 0.1,
        metalness: 0.8,
        transparent: isTransparent,
        opacity: isTransparent ? 0.3 : 1.0,
        transmission: isTransparent ? 0.2 : 0,
        clearcoat: 1.0,
        clearcoatRoughness: 0.05,
        envMapIntensity: 2.0,
        side: THREE.DoubleSide,
        depthWrite: !isTransparent
    }), [c1, isTransparent]);

    const material2 = useMemo(() => new THREE.MeshPhysicalMaterial({
        color: c2,
        roughness: 0.1,
        metalness: 0.8,
        transparent: isTransparent,
        opacity: isTransparent ? 0.3 : 1.0,
        transmission: isTransparent ? 0.2 : 0,
        clearcoat: 1.0,
        clearcoatRoughness: 0.05,
        envMapIntensity: 2.0,
        side: THREE.DoubleSide,
        depthWrite: !isTransparent
    }), [c2, isTransparent]);

    const geometry = useMemo(() => new THREE.TetrahedronGeometry(radius, 0), [radius]);

    return (
        <group>
            {/* T1: Pointing Up/Right */}
            <group rotation={[0, 0, 0]}>
                <mesh castShadow receiveShadow geometry={geometry} material={material1} />
                <lineSegments>
                    <edgesGeometry args={[geometry]} />
                    <lineBasicMaterial color={isTransparent ? "#ffffff" : "#ffffff"} transparent opacity={0.4} />
                </lineSegments>
            </group>
            
            {/* T2: Pointing Down/Left (Dual) */}
            {!showHalfStella && (
                <group rotation={[Math.PI, 0, Math.PI / 2]}>
                     <mesh castShadow receiveShadow geometry={geometry} material={material2} />
                     <lineSegments>
                        <edgesGeometry args={[geometry]} />
                        <lineBasicMaterial color={isTransparent ? "#ffffff" : "#ffffff"} transparent opacity={0.4} />
                    </lineSegments>
                </group>
            )}
        </group>
    );
};

export const StellaHalf: React.FC<{ side: 'left' | 'right'; color: string; isTransparent: boolean; showHalfStella?: boolean; gapSize: number; }> = ({ side, color, isTransparent, showHalfStella, gapSize }) => {
    const radius = 5.196;
    const isLeft = side === 'left';
    const meshGroupRef = useRef<THREE.Group>(null);
    const localX = isLeft ? 1.5 : -1.5;

    // Clipping plane setup
    const clippingPlane = useMemo(() => {
        const normal = new THREE.Vector3(isLeft ? -1 : 1, 0, 0);
        return new THREE.Plane(normal, 0);
    }, [isLeft]);

    // Update clipping plane every frame to match mesh position perfectly
    useFrame(() => {
        if (meshGroupRef.current) {
            const worldPos = new THREE.Vector3();
            meshGroupRef.current.getWorldPosition(worldPos);
            // Epsilon offset to prevent Z-fighting
            const epsilon = 0.002;
            clippingPlane.constant = isLeft ? (worldPos.x - epsilon) : (-worldPos.x - epsilon);
        }
    });

    const [c1, c2] = useMemo(() => getStellaColors(color), [color]);

    const mat1 = useMemo(() => new THREE.MeshPhysicalMaterial({
        color: c1, roughness: 0.05, metalness: 0.7,
        clippingPlanes: [clippingPlane], clipShadows: true,
        transparent: isTransparent, 
        opacity: isTransparent ? 0.3 : 1.0,
        transmission: isTransparent ? 0.2 : 0, 
        clearcoat: 1.0, clearcoatRoughness: 0.02, envMapIntensity: 2.5, 
        side: THREE.DoubleSide,
        depthWrite: !isTransparent
    }), [c1, clippingPlane, isTransparent]);

    const mat2 = useMemo(() => new THREE.MeshPhysicalMaterial({
        color: c2, roughness: 0.05, metalness: 0.7,
        clippingPlanes: [clippingPlane], clipShadows: true,
        transparent: isTransparent, 
        opacity: isTransparent ? 0.3 : 1.0,
        transmission: isTransparent ? 0.2 : 0,
        clearcoat: 1.0, clearcoatRoughness: 0.02, envMapIntensity: 2.5, 
        side: THREE.DoubleSide,
        depthWrite: !isTransparent
    }), [c2, clippingPlane, isTransparent]);

    // Physical Cap Logic (Black plane filling the cut)
    const capSize = 3 * Math.sqrt(2);
    const capMat = useMemo(() => new THREE.MeshBasicMaterial({
        color: '#000000',
        side: THREE.DoubleSide,
        depthWrite: true
    }), []);

    const geometry = useMemo(() => new THREE.TetrahedronGeometry(radius, 0), [radius]);
    
    // Line material supporting clipping
    const lineMaterial = useMemo(() => new THREE.LineBasicMaterial({
        color: '#ffffff',
        transparent: true,
        opacity: 0.4,
        clippingPlanes: [clippingPlane]
    }), [clippingPlane]);

    // Rotation for the square cap to match the diamond cross-section of the cut
    const capRotation: [number, number, number] = [0, isLeft ? Math.PI/2 : -Math.PI/2, Math.PI/4];

    return (
        <group position={[localX, 0, 0]} ref={meshGroupRef}>
            
            {/* The Visible Clipped Geometry */}
            <group>
                <group rotation={[0, 0, 0]}>
                    <mesh castShadow geometry={geometry} material={mat1} />
                    <lineSegments geometry={new THREE.EdgesGeometry(geometry)} material={lineMaterial} />
                </group>
                {!showHalfStella && (
                     <group rotation={[Math.PI, 0, Math.PI / 2]}>
                        <mesh castShadow geometry={geometry} material={mat2} />
                        <lineSegments geometry={new THREE.EdgesGeometry(geometry)} material={lineMaterial} />
                    </group>
                )}
            </group>

            {/* The Physical Cap - Only Render if Opaque */}
            {!isTransparent && (
                <group rotation={capRotation}>
                    <mesh material={capMat}>
                         <planeGeometry args={[capSize, capSize]} />
                    </mesh>
                </group>
            )}

        </group>
    );
};

export const StellaVerseLayer: React.FC<{
    cubeColor: string,
    fontLoaded: boolean,
    selectedFont: string,
    isBold: boolean,
    showHalfStella?: boolean
}> = ({ cubeColor, fontLoaded, selectedFont, isBold, showHalfStella }) => {
    const scale = 3.0;
    
    // T1 Vertices (Regular Tetrahedron)
    // Vertices at (1,1,1), (1,-1,-1), (-1,1,-1), (-1,-1,1)
    const vT1 = useMemo(() => [
        new THREE.Vector3(1, 1, 1), 
        new THREE.Vector3(1, -1, -1), 
        new THREE.Vector3(-1, 1, -1), 
        new THREE.Vector3(-1, -1, 1)
    ], []);

    // T2 Vertices (Dual Tetrahedron)
    // Vertices at (-1,-1,-1), (-1,1,1), (1,-1,1), (1,1,-1)
    const vT2 = useMemo(() => [
        new THREE.Vector3(-1, -1, -1), 
        new THREE.Vector3(-1, 1, 1), 
        new THREE.Vector3(1, -1, 1),
        new THREE.Vector3(1, 1, -1) 
    ], []);

    const elements: React.ReactElement[] = [];
    const letterColor = "#000000";
    const charScale: [number, number, number] = [1.22, 1.22, 1.22]; 

    const [c1, c2] = useMemo(() => getStellaColors(cubeColor), [cubeColor]);

    const generateForTetrahedron = (vertices: THREE.Vector3[], tetName: string) => {
        const tetColor = tetName === 'T1' ? c1 : c2;

        vertices.forEach((tipVertex, i) => {
            let charToPlace = "ה";
            if (tetName === 'T1') {
                if(i===0) charToPlace = "י";
                else if(i===1) charToPlace = "ה";
                else if(i===2) charToPlace = "ו";
                else charToPlace = "ה";
            } else if (tetName === 'T2') {
                if(i===0) charToPlace = "א";
                else if(i===1) charToPlace = "ד";
                else if(i===2) charToPlace = "נ";
                else charToPlace = "י";
            }

            const tip = tipVertex.clone().multiplyScalar(scale);
            const others = vertices.filter((_, idx) => idx !== i);
            const pairs = [[0,1], [1,2], [2,0]];
            
            pairs.forEach((pair, pairIdx) => {
                const p1 = others[pair[0]].clone().multiplyScalar(scale);
                const p2 = others[pair[1]].clone().multiplyScalar(scale);
                
                // Calculate position slightly offset from the tip along the face
                const vec1 = p1.clone().sub(tip);
                const vec2 = p2.clone().sub(tip);
                
                // Position: Tip + small step towards p1 + small step towards p2
                const pos = tip.clone().add(vec1.multiplyScalar(0.05)).add(vec2.multiplyScalar(0.05));
                
                // Calculate Normal
                const edgeA = vec1.clone();
                const edgeB = vec2.clone();
                
                // Safety check for cross product to avoid NaNs if vertices are somehow collinear (shouldn't happen with valid tetrahedron)
                const cross = new THREE.Vector3().crossVectors(edgeA, edgeB);
                if (cross.lengthSq() < 0.0001) return; // Skip invalid faces
                
                let normal = cross.normalize();
                
                // Ensure normal points OUT
                if (normal.dot(pos) < 0) normal.negate();
                
                // Orientation
                const toTip = tip.clone().sub(pos).normalize();
                const basisY = toTip; 
                const basisX = new THREE.Vector3().crossVectors(basisY, normal).normalize();
                const basisZ = normal;
                
                const rotMatrix = new THREE.Matrix4().makeBasis(basisX, basisY, basisZ);
                const qt = new THREE.Quaternion().setFromRotationMatrix(rotMatrix);
                const euler = new THREE.Euler().setFromQuaternion(qt);
                
                // Lift text slightly off surface
                const finalPos = pos.clone().add(normal.multiplyScalar(0.04));

                elements.push(
                    <CharTexturePlane 
                        key={`${tetName}-v${i}-f${pairIdx}`}
                        char={charToPlace}
                        textColor={letterColor}
                        backgroundColor={undefined}
                        position={[finalPos.x, finalPos.y, finalPos.z]}
                        rotation={[euler.x, euler.y, euler.z]}
                        scale={charScale}
                        cubeColor={tetColor}
                        fontLoaded={fontLoaded}
                        isEngraved={false}
                        selectedFont={selectedFont}
                        isBold={isBold}
                        plainText={true}
                    />
                );
            });
        });
    }
    
    generateForTetrahedron(vT1, 'T1');
    if (!showHalfStella) generateForTetrahedron(vT2, 'T2');
    
    return <group>{elements}</group>;
};
