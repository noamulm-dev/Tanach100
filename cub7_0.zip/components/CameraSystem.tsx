
import React, { useLayoutEffect, useRef, useCallback } from 'react';
import { useThree, useFrame } from '@react-three/fiber';
import { Html, OrbitControls, TrackballControls } from '@react-three/drei';
import * as THREE from 'three';
import type { ShapeType } from '../types';

export const StableOrbitControls: React.FC<{ currentShape: ShapeType }> = ({ currentShape }) => {
    // For "reading" modes (Boards) or standard cubes, OrbitControls is better (keeps horizon).
    // For 3D geometries (Sphere, Stella, Polyhedrons), Trackball allows full 360 "in-hand" inspection without pole locks.
    const useTrackball = ['sphere', 'stella', 'octahedron', 'dodecahedron', 'icosahedron'].includes(currentShape);

    if (useTrackball) {
        return (
            <TrackballControls 
                makeDefault 
                rotateSpeed={4.0} 
                staticMoving={true} // Disables inertia
                noZoom={false}
                noPan={false}
            />
        );
    }

    return <OrbitControls makeDefault enableDamping={false} />;
};

export const ZoomFitter = React.memo<{
    splitState: number;
    currentShape: ShapeType;
    viewOrientation: 'iso' | 'top' | 'bottom' | 'front' | 'back' | 'right' | 'left' | 'side';
    trigger: number;
    isDebugMode?: boolean;
    cameraType: 'ortho' | 'perspective';
    fov?: number;
    gapSize?: number;
    verticalSpread?: number;
    topOffset?: number;
}>(({ splitState, currentShape, viewOrientation, trigger, isDebugMode = false, cameraType, fov = 20, topOffset = 0 }) => {
    const { camera, size, controls } = useThree();
    
    const stateRef = useRef({
        visibleHeight: 12.0, // Reduced from 14.5 for closer initial zoom
        target: new THREE.Vector3(0, 0, 0),
        azimuth: Math.PI / 4,
        polar: Math.PI / 3,
        valid: false
    });

    const prevCamType = useRef(cameraType);
    const prevTrigger = useRef(trigger);
    const prevShape = useRef(currentShape);
    const prevOrientation = useRef(viewOrientation);
    const prevSplit = useRef(splitState);
    const prevTopOffset = useRef(topOffset);
    const hasInitialized = useRef(false);

    const debugRef = useRef<HTMLDivElement>(null);

    const getStandardFit = useCallback(() => {
        // Closer zoom: visibleUnits 12.0 is more 'punched in' than 14.5
        // Dodecahedron and Icosahedron have radius ~3.0-3.5, similar to Sphere/Octahedron
        const isBoundingShape = currentShape === 'sphere' || currentShape === 'stella' || currentShape === 'octahedron' || currentShape === 'dodecahedron' || currentShape === 'icosahedron';
        const visibleUnits = isBoundingShape ? 11.5 : 12.5; 
        
        const minDim = Math.min(size.width, size.height);
        if (minDim === 0) return { pos: new THREE.Vector3(0,0,100), target: new THREE.Vector3(0,0,0), up: new THREE.Vector3(0,1,0), height: 12.0 };

        const aspect = size.width / size.height;
        let targetHeight = visibleUnits;
        if (aspect < 1) { 
            targetHeight = visibleUnits / aspect;
        }

        let dir = new THREE.Vector3();
        let up = new THREE.Vector3(0, 1, 0);

        switch (viewOrientation) {
            case 'top': 
                dir.set(0, 1, 0); 
                if (currentShape === 'boards') up.set(-1, 0, 0); else up.set(0, 0, -1);
                break;
            case 'bottom': 
                dir.set(0, -1, 0); 
                if (currentShape === 'boards') up.set(1, 0, 0); else up.set(0, 0, 1);
                break;
            case 'front': dir.set(0, 0, 1); break;
            case 'back': dir.set(0, 0, -1); break;
            case 'right': dir.set(1, 0, 0); break;
            case 'left': dir.set(-1, 0, 0); break;
            case 'side': dir.set(0, 0, 1); break;
            case 'iso':
            default:
                dir.set(1, 1, 1).normalize();
                break;
        }

        const isMobile = size.width < 768;
        
        // Calculate offsets based on actual UI dimensions
        // Top offset is measured dynamically. Bottom offset is roughly fixed for controls.
        // We add a small padding (20px) to the top offset to avoid the object touching the header.
        const UI_TOP = topOffset > 0 ? topOffset + 10 : (isMobile ? 80 : 60); 
        const UI_BOTTOM = isMobile ? 160 : 100; // Estimated height of bottom controls
        
        // Calculate the "Visual Center" in pixel coordinates
        // Available height = Total Height - Top UI - Bottom UI
        // Center of Available space = Top UI + (Available Height / 2)
        const availableHeight = size.height - UI_TOP - UI_BOTTOM;
        
        // If screen is extremely small, fallback to center to avoid weird shifts
        const safeAvailableHeight = Math.max(availableHeight, 100); 
        
        const visualCenterY = UI_TOP + (safeAvailableHeight / 2);
        const screenCenterY = size.height / 2;
        
        // Positive pixel shift means the target needs to move DOWN in screen space
        // Which translates to moving the camera UP relative to target (or target DOWN relative to camera)
        // In Three.js world coordinates: +Y is Up.
        // If Visual Center is lower than Screen Center (e.g. big header), we need to shift the World Center DOWN.
        const pixelShiftY = visualCenterY - screenCenterY;
        
        // Convert pixel shift to world units at the target distance
        const worldShiftY = (pixelShiftY / size.height) * targetHeight;
        
        const origin = new THREE.Vector3(0,0,0);
        const forward = dir.clone().normalize();
        const right = new THREE.Vector3().crossVectors(forward, up).normalize();
        const actualUp = new THREE.Vector3().crossVectors(right, forward).normalize();
        
        // Apply the shift along the camera's up vector.
        const targetOffset = actualUp.clone().multiplyScalar(worldShiftY);
        const target = origin.clone().add(targetOffset);

        return { dir, target, up: actualUp, height: targetHeight };
    }, [size, currentShape, viewOrientation, splitState, topOffset]);

    const applyToCamera = useCallback((
        targetHeight: number, 
        target: THREE.Vector3, 
        directionOrPos: THREE.Vector3,
        up: THREE.Vector3,
        isDirection: boolean
    ) => {
        if (size.height === 0) return;

        let safeHeight = targetHeight;
        if (safeHeight < 1) safeHeight = 1;
        if (safeHeight > 1000) safeHeight = 1000;

        let newPos = new THREE.Vector3();
        let newDist = 200;

        if (cameraType === 'ortho') {
            const cam = camera as THREE.OrthographicCamera;
            let newZoom = size.height / safeHeight;
            if (newZoom < 0.1) newZoom = 0.1;
            if (newZoom > 2000) newZoom = 2000;
            cam.zoom = newZoom;
            cam.left = -size.width / 2;
            cam.right = size.width / 2;
            cam.top = size.height / 2;
            cam.bottom = -size.height / 2;
            cam.updateProjectionMatrix();
            newDist = 200;
        } else {
            const cam = camera as THREE.PerspectiveCamera;
            cam.fov = fov;
            cam.updateProjectionMatrix();
            const fovRad = (fov * Math.PI) / 180;
            newDist = safeHeight / (2 * Math.tan(fovRad / 2));
            if (newDist < 0.1) newDist = 0.1;
            if (newDist > 5000) newDist = 5000;
        }

        if (isDirection) {
            newPos.copy(directionOrPos).normalize().multiplyScalar(newDist).add(target);
        } else {
            const currentVec = new THREE.Vector3().subVectors(directionOrPos, target);
            newPos.copy(target).add(currentVec.normalize().multiplyScalar(newDist));
        }

        camera.position.copy(newPos);
        camera.up.copy(up);
        camera.lookAt(target);

        if (controls) {
            const ctrl = controls as any;
            ctrl.target.copy(target);
            ctrl.update();
            stateRef.current.visibleHeight = safeHeight;
            stateRef.current.target.copy(target);
            stateRef.current.valid = true;
            if (typeof ctrl.getAzimuthalAngle === 'function') {
                 stateRef.current.azimuth = ctrl.getAzimuthalAngle();
                 stateRef.current.polar = ctrl.getPolarAngle();
            } else {
                 const vec = new THREE.Vector3().subVectors(camera.position, target);
                 const r = vec.length();
                 if (r > 0.001) {
                    stateRef.current.polar = Math.acos(THREE.MathUtils.clamp(vec.y / r, -1, 1));
                    stateRef.current.azimuth = Math.atan2(vec.x, vec.z);
                 }
            }
        }
    }, [camera, cameraType, fov, size, controls]);

    useFrame((state) => {
        if (!controls || size.height === 0) return;
        const ctrl = state.controls as any;
        let currentHeight = 12.0;
        if (cameraType === 'ortho') {
            const cam = camera as THREE.OrthographicCamera;
            const z = cam.zoom;
            if (z > 0.01) currentHeight = size.height / z;
        } else {
            const cam = camera as THREE.PerspectiveCamera;
            const dist = camera.position.distanceTo(ctrl.target);
            const fovRad = (cam.fov * Math.PI) / 180;
            currentHeight = 2 * dist * Math.tan(fovRad / 2);
        }

        if (!Number.isNaN(currentHeight) && currentHeight > 0.01) {
            stateRef.current.visibleHeight = currentHeight;
            stateRef.current.target.copy(ctrl.target);
            stateRef.current.valid = true;
            if (typeof ctrl.getAzimuthalAngle === 'function') {
                 stateRef.current.azimuth = ctrl.getAzimuthalAngle();
                 stateRef.current.polar = ctrl.getPolarAngle();
            } else {
                 const vec = new THREE.Vector3().subVectors(camera.position, ctrl.target);
                 const r = vec.length();
                 if (r > 0.001) {
                     stateRef.current.polar = Math.acos(THREE.MathUtils.clamp(vec.y / r, -1, 1));
                     stateRef.current.azimuth = Math.atan2(vec.x, vec.z);
                 }
            }
        }
    });

    useLayoutEffect(() => {
        if (size.width === 0 || size.height === 0) return;
        const isTrigger = trigger !== prevTrigger.current;
        const isShapeChange = currentShape !== prevShape.current;
        const isOriChange = viewOrientation !== prevOrientation.current;
        const isSplitChange = splitState !== prevSplit.current;
        const isTypeChange = cameraType !== prevCamType.current;
        // Trigger resize if topOffset changes significantly (> 5px to avoid jitter)
        const isOffsetChange = Math.abs(topOffset - prevTopOffset.current) > 5;
        
        const needsStandardFit = isTrigger || isShapeChange || isOriChange || isSplitChange || isOffsetChange || !hasInitialized.current || !stateRef.current.valid;
        const oldCamType = prevCamType.current;
        prevTrigger.current = trigger;
        prevShape.current = currentShape;
        prevOrientation.current = viewOrientation;
        prevSplit.current = splitState;
        prevCamType.current = cameraType;
        prevTopOffset.current = topOffset;
        
        if (needsStandardFit) {
            const fit = getStandardFit();
            applyToCamera(fit.height, fit.target, fit.dir, fit.up, true);
            hasInitialized.current = true;
        } 
        else if (isTypeChange) {
            let height = stateRef.current.visibleHeight;
            const target = stateRef.current.target;
            const spherical = new THREE.Spherical(100, stateRef.current.polar, stateRef.current.azimuth); 
            const offset = new THREE.Vector3().setFromSpherical(spherical);
            const pos = target.clone().add(offset); 
            applyToCamera(height, target, pos, new THREE.Vector3(0,1,0), false);
        }
    }, [cameraType, trigger, currentShape, viewOrientation, splitState, size, getStandardFit, applyToCamera, topOffset]);

    return null;
});
