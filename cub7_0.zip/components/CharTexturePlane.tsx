
import React, { useMemo } from 'react';
import * as THREE from 'three';
import '../types'; 

const textureCache: Record<string, THREE.CanvasTexture> = {};
const sharedPlaneGeometry = new THREE.PlaneGeometry(0.96, 0.96); 

export const CharTexturePlane: React.FC<{
  char: string;
  textColor?: string;
  backgroundColor?: string;
  position: [number, number, number];
  rotation?: [number, number, number];
  scale?: [number, number, number];
  cubeColor: string;
  fontLoaded: boolean;
  isEngraved: boolean;
  selectedFont: string;
  isBold: boolean;
  opacity?: number;
  plainText?: boolean;
}> = React.memo(({ char, textColor, backgroundColor, position, rotation = [0, 0, 0], scale = [1, 1, 1], cubeColor, fontLoaded, isEngraved, selectedFont, isBold, opacity = 1.0, plainText = false }) => {
  
  const texture = useMemo(() => {
    const bgKey = backgroundColor ? backgroundColor : 'none';
    const cacheKey = `${char}-${cubeColor}-${textColor || 'def'}-${fontLoaded}-${isEngraved}-${selectedFont}-${isBold ? 'bold' : 'normal'}-${bgKey}-${plainText ? 'plain' : 'effect'}-res512`;
    if (textureCache[cacheKey]) return textureCache[cacheKey];

    // Increased resolution for sharpness (was 128)
    const size = 512;
    const center = size / 2;
    
    const canvas = document.createElement('canvas');
    canvas.width = size; canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      if (backgroundColor) {
          ctx.fillStyle = backgroundColor;
          ctx.fillRect(0, 0, size, size);
      } else {
          ctx.clearRect(0, 0, size, size);
      }
      const weightPrefix = isBold ? 'bold' : 'normal';
      // Increased font size proportionally (was 80px)
      ctx.font = `${weightPrefix} 320px "${selectedFont}", "Stam", serif`; 
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.direction = 'rtl';

      let fillColor, shadowColor, highlightColor;
      const effectiveBgColor = backgroundColor || cubeColor;
      const c = new THREE.Color(effectiveBgColor);
      const isDark = (c.r * 299 + c.g * 587 + c.b * 114) / 1000 < 0.5;

      if (isDark) {
          fillColor = '#ffffff'; 
          shadowColor = 'rgba(0,0,0,0.5)';
          highlightColor = 'rgba(255,215,0,0.4)';
      } else {
          fillColor = '#000000';
          shadowColor = 'rgba(0,0,0,0.3)';
          highlightColor = 'rgba(255,255,255,0.8)';
      }

      if (textColor) {
          fillColor = textColor;
          if (!isDark) {
              shadowColor = 'rgba(0,0,0,0.8)'; 
              highlightColor = 'rgba(0,0,0,0)'; 
          } else {
              shadowColor = 'rgba(255,255,255,0.6)';
              highlightColor = 'rgba(255,255,255,0.4)';
          }
      }

      // Offsets scaled for 512px (approx 4x the original 128px offsets)
      const shadowOffset = 8; 

      if (plainText) {
          ctx.fillStyle = fillColor;
          ctx.fillText(char, center, center);
      }
      else if (isEngraved) {
          ctx.fillStyle = 'rgba(255,255,255, 0.7)';
          ctx.fillText(char, center + 4, center + 4); 
          ctx.fillStyle = fillColor;
          ctx.fillText(char, center, center);
      } 
      else {
          // Shadow
          ctx.fillStyle = shadowColor; 
          ctx.fillText(char, center - shadowOffset, center - shadowOffset); 
          
          // Highlight (only if needed)
          if (!textColor || (textColor && isDark)) {
              ctx.fillStyle = highlightColor; 
              ctx.fillText(char, center + shadowOffset, center + shadowOffset); 
          }
          
          // Main Text
          ctx.fillStyle = fillColor;
          ctx.fillText(char, center, center);
      }
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    // Anisotropy helps with sharpness at angles
    tex.anisotropy = 4; 
    textureCache[cacheKey] = tex;
    return tex;
  }, [char, cubeColor, textColor, fontLoaded, isEngraved, selectedFont, isBold, backgroundColor, plainText]);

  return (
    <mesh position={position} rotation={rotation} scale={scale} geometry={sharedPlaneGeometry}>
      <meshBasicMaterial 
        map={texture} 
        transparent 
        opacity={opacity}
        side={THREE.DoubleSide} 
        depthWrite={true} 
        alphaTest={opacity < 0.9 ? 0 : 0.1} 
      />
    </mesh>
  );
});
