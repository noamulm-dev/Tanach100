
import React from 'react';
import type { ShapeType, Language, BookType } from '../types';

interface ControlsProps {
  onCycleColor: () => void;
  splitState: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7;
  onSetSplit: (state: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7) => void;
  currentShape: ShapeType;
  onSetShape: (shape: ShapeType) => void;
  gapSize: number;
  onGapChange: (val: number) => void;
  verticalSpread: number;
  onVerticalSpreadChange: (val: number) => void;
  lang: Language;
  translations: any;
  useMultiColor: boolean;
  onToggleMultiColor: () => void;
  onToggleTriplets?: () => void;
  viewOrientation: 'iso' | 'top' | 'bottom' | 'front' | 'back' | 'right' | 'left' | 'side';
  onSetViewOrientation: (o: 'iso' | 'top' | 'bottom' | 'front' | 'back' | 'right' | 'left' | 'side') => void;
  highlightLayer: number; 
  onHighlightLayerChange: (val: number) => void;
  showStellaGrid?: boolean;
  onToggleStellaGrid?: () => void;
  showHalfStella?: boolean;
  onToggleHalfStella?: () => void;
  theme?: 'dark' | 'light';
}

// --- NEW DISTINCT ICONS ---

const IconIso = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
    <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
    <line x1="12" y1="22.08" x2="12" y2="12" />
  </svg>
);

const IconTop = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 3v9" />
    <path d="M8 8l4 4 4-4" />
    <rect x="5" y="14" width="14" height="6" rx="2" strokeOpacity="0.5" />
    <path d="M5 14l3-3h8l3 3" strokeOpacity="0.5" />
  </svg>
);

const IconBottom = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 21V12" />
    <path d="M8 16l4-4 4 4" />
    <rect x="5" y="4" width="14" height="6" rx="2" strokeOpacity="0.5" />
    <path d="M5 10l3 3h8l3-3" strokeOpacity="0.5" />
  </svg>
);

const IconFront = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="4" y="4" width="16" height="16" rx="2" />
    <rect x="9" y="9" width="6" height="6" fill="currentColor" stroke="none" />
  </svg>
);

const IconBack = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="6" y="6" width="14" height="14" rx="2" />
    <path d="M4 4h10" strokeDasharray="2 2" />
    <path d="M4 4v10" strokeDasharray="2 2" />
  </svg>
);

const IconRight = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
     <path d="M4 4h8v16H4z" strokeOpacity="0.5" />
     <path d="M12 4l6 4v12l-6-4" fill="currentColor" stroke="none" fillOpacity="0.6" />
     <path d="M12 4l6 4v12l6-4" />
     <path d="M4 4l6 4" strokeOpacity="0.5" />
  </svg>
);

const IconLeft = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
     <path d="M12 4h8v16h-8z" strokeOpacity="0.5" />
     <path d="M12 4l-6 4v12l6-4" fill="currentColor" stroke="none" fillOpacity="0.6" />
     <path d="M12 4l-6 4v12l6-4" />
     <path d="M20 4l-6 4" strokeOpacity="0.5" />
  </svg>
);

const IconGrid = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="18" height="18" rx="2" strokeOpacity="0.5" />
    <circle cx="8" cy="8" r="1.5" fill="currentColor" />
    <circle cx="16" cy="8" r="1.5" fill="currentColor" />
    <circle cx="8" cy="16" r="1.5" fill="currentColor" />
    <circle cx="16" cy="16" r="1.5" fill="currentColor" />
    <path d="M3 12h18M12 3v18" strokeOpacity="0.3" />
  </svg>
);

const IconHalf = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 21h18L12 3z" />
      <path d="M12 3v18" strokeDasharray="2 2" />
  </svg>
);

export const Controls: React.FC<ControlsProps> = React.memo(({
  onCycleColor,
  splitState,
  onSetSplit,
  currentShape,
  onSetShape,
  gapSize,
  onGapChange,
  verticalSpread,
  onVerticalSpreadChange,
  lang,
  translations,
  useMultiColor,
  onToggleMultiColor,
  onToggleTriplets,
  viewOrientation,
  onSetViewOrientation,
  highlightLayer,
  onHighlightLayerChange,
  showStellaGrid,
  onToggleStellaGrid,
  showHalfStella,
  onToggleHalfStella,
  theme = 'dark'
}) => {
  
  const t = translations[lang];
  const isRTL = lang === 'he';
  const isDark = theme === 'dark';

  const isGapEnabled = (currentShape === 'cube' && splitState !== 2) || 
                       (currentShape === 'boards') || 
                       ((currentShape === 'sphere' || currentShape === 'stella' || currentShape === 'dodecahedron' || currentShape === 'icosahedron' || currentShape === 'octahedron') && splitState === 1);

  const isVGapEnabled = currentShape === 'cube' || currentShape === 'boards';

  const getVisibleLayouts = () => {
      if (currentShape === 'cube') {
          return [0, 1, 2]; // Whole, Split, Long
      } else if (currentShape === 'boards') {
          return [5, 6]; 
      } else if (currentShape === 'sphere' || currentShape === 'stella' || currentShape === 'dodecahedron' || currentShape === 'icosahedron' || currentShape === 'octahedron') {
          return [0, 1]; // Whole, Split (halves)
      }
      return [];
  };

  const visibleLayouts = getVisibleLayouts();
  
  const ViewButton = ({ view, icon, label }: { view: string, icon: React.ReactNode, label: string }) => (
      <button
          onClick={() => onSetViewOrientation(view as any)}
          title={label}
          aria-label={label}
          className={`p-1 rounded transition-colors ${viewOrientation === view ? 'bg-[#eab308] text-black font-bold shadow-lg scale-105' : (isDark ? 'text-gray-400 hover:text-white hover:bg-white/5' : 'text-gray-500 hover:text-black hover:bg-black/5')}`}
      >
          {icon}
      </button>
  );

  const isStella = currentShape === 'stella';
  const isLatticeShape = currentShape === 'stella' || currentShape === 'octahedron' || currentShape === 'dodecahedron' || currentShape === 'icosahedron';
  
  // Only show the "Remove Tetrahedron" button for Stella
  const showHalfStellaButton = isStella;

  const bgClass = isDark ? 'bg-[#050505] border-white/10' : 'bg-white border-gray-200';
  const buttonBg = isDark ? 'bg-white/5 hover:bg-white/10 border-white/5' : 'bg-black/5 hover:bg-black/10 border-black/5';
  const labelColor = isDark ? 'text-gray-500' : 'text-gray-500';

  return (
    <div 
      className={`w-full ${bgClass} border-t flex flex-col shrink-0 z-50 shadow-2xl pb-6 pt-2`} 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <div className="flex flex-col w-full max-w-5xl mx-auto px-4 gap-3">
        <div className={`flex justify-center w-full pb-2 border-b ${isDark ? 'border-white/5' : 'border-black/5'} overflow-x-auto`}>
            <div className={`flex gap-1 ${isDark ? 'bg-white/5' : 'bg-black/5'} p-1 rounded-lg shrink-0`}>
                <div className={`flex gap-1 border-r ${isDark ? 'border-white/10' : 'border-black/10'} pr-1`}>
                    <ViewButton view="top" icon={<IconTop />} label={t.viewTop} />
                    <ViewButton view="bottom" icon={<IconBottom />} label={t.viewBottom} />
                </div>
                <div className={`flex gap-1 border-r ${isDark ? 'border-white/10' : 'border-black/10'} px-1`}>
                    <ViewButton view="front" icon={<IconFront />} label={t.viewFront} />
                    <ViewButton view="back" icon={<IconBack />} label={t.viewBack} />
                </div>
                <div className={`flex gap-1 border-r ${isDark ? 'border-white/10' : 'border-black/10'} px-1`}>
                    <ViewButton view="right" icon={<IconRight />} label={t.viewRight} />
                    <ViewButton view="left" icon={<IconLeft />} label={t.viewLeft} />
                </div>
                <div className="flex gap-1 pl-1">
                    <ViewButton view="iso" icon={<IconIso />} label={t.viewIso} />
                </div>
            </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 w-full">
          <div className="flex items-center gap-4 flex-1 justify-between min-w-[200px]">
              <div className="h-full flex items-end pb-1 gap-2">
                <button onClick={onCycleColor} className={`p-2 ${buttonBg} rounded-lg border transition-all active:scale-95 flex-shrink-0`} title={t.color}>
                    <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-blue-400 to-purple-500 shadow-sm" />
                </button>
                {(currentShape === 'boards') && (
                     <>
                         <button onClick={onToggleMultiColor} className={`p-2 ${buttonBg} rounded-lg border transition-all active:scale-95 flex-shrink-0`} title={t.colorMode}>
                             <div className="w-5 h-5 rounded-full shadow-sm border border-white/20" style={{background: useMultiColor ? 'linear-gradient(to right, #4ade80, #f87171, #facc15)' : 'linear-gradient(to right, #333, #ccc)'}} />
                         </button>
                     </>
                )}
                {isLatticeShape && (
                     <button onClick={onToggleStellaGrid} className={`p-2 rounded-lg border ${isDark ? 'border-white/5' : 'border-black/5'} transition-all active:scale-95 flex-shrink-0 ${showStellaGrid ? 'bg-yellow-500/20 text-yellow-500 border-yellow-500/30' : `${buttonBg} ${isDark ? 'text-gray-300' : 'text-gray-600'}`}`} title={t.grid}>
                         <IconGrid />
                     </button>
                )}
                 {showHalfStellaButton && onToggleHalfStella && (
                     <button onClick={onToggleHalfStella} className={`p-2 rounded-lg border ${isDark ? 'border-white/5' : 'border-black/5'} transition-all active:scale-95 flex-shrink-0 ${showHalfStella ? 'bg-pink-500/20 text-pink-500 border-pink-500/30' : `${buttonBg} ${isDark ? 'text-gray-300' : 'text-gray-600'}`}`} title={t.halfStella}>
                         <IconHalf />
                     </button>
                )}
            </div>
            
             <div className={`flex flex-col flex-1 max-w-[160px] transition-opacity duration-300 ${currentShape === 'octahedron' && splitState !== 1 ? 'hidden' : (isGapEnabled ? 'opacity-100' : 'opacity-20 pointer-events-none')}`}>
               <div className={`flex justify-between items-center text-[10px] ${labelColor} font-bold uppercase mb-1`}>
                 <span>{t.gap}</span>
                 <span className="text-blue-400 font-mono">{gapSize.toFixed(1)}</span>
               </div>
               <input 
                 type="range" 
                 min="1" 
                 max={(currentShape === 'sphere' || currentShape === 'stella' || currentShape === 'dodecahedron' || currentShape === 'icosahedron' || currentShape === 'octahedron') ? 2 : 11} 
                 step="0.1" 
                 value={gapSize} 
                 disabled={!isGapEnabled}
                 onChange={(e) => onGapChange(parseFloat(e.target.value))}
                 className={`w-full h-2 ${isDark ? 'bg-gray-800' : 'bg-gray-300'} rounded-lg appearance-none cursor-pointer accent-blue-500 hover:accent-blue-400`}
               />
            </div>

            <div className={`flex flex-col flex-1 max-w-[160px] transition-opacity duration-300 ${isLatticeShape ? 'hidden' : (isVGapEnabled ? 'opacity-100' : 'opacity-20 pointer-events-none')}`}>
                   <div className={`flex justify-between items-center text-[10px] ${labelColor} font-bold uppercase mb-1`}>
                     <span>{t.vGap}</span>
                     <span className="text-green-400 font-mono">{verticalSpread.toFixed(1)}</span>
                   </div>
                   <input 
                     type="range" 
                     min="1" 
                     max="3" 
                     step="0.1" 
                     value={verticalSpread} 
                     disabled={!isVGapEnabled}
                     onChange={(e) => onVerticalSpreadChange(parseFloat(e.target.value))}
                     className={`w-full h-2 ${isDark ? 'bg-gray-800' : 'bg-gray-300'} rounded-lg appearance-none cursor-pointer accent-green-500 hover:accent-green-400`}
                   />
            </div>
          </div>
        </div>

        <div className={`flex flex-col items-center w-full transition-all duration-500 h-10`}>
            <div className={`flex flex-wrap justify-center gap-2 w-full transition-opacity duration-300 ${visibleLayouts.length > 0 ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
              {visibleLayouts.map((s) => {
                const stateIndex = s as 0|1|2|3|4|5|6|7;
                let labelKey = `l${s}`;
                if (currentShape === 'cube') {
                     if (s === 0) labelKey = 'c0';
                     if (s === 1) labelKey = 'c1';
                     if (s === 2) labelKey = 'c2';
                }
                else if (currentShape === 'sphere' || currentShape === 'stella' || currentShape === 'dodecahedron' || currentShape === 'icosahedron' || currentShape === 'octahedron') {
                     if (s === 0) labelKey = 'w0'; 
                     if (s === 1) labelKey = 'w1'; 
                }
                const isActive = splitState === stateIndex;
                return (
                  <button
                    key={s}
                    onClick={() => {
                        onSetSplit(stateIndex);
                        if (stateIndex === 0 && (currentShape === 'sphere' || currentShape === 'stella' || currentShape === 'dodecahedron' || currentShape === 'icosahedron' || currentShape === 'octahedron')) {
                            onGapChange(1.0);
                        }
                    }}
                    className={`flex-1 min-w-[60px] max-w-[140px] py-2 px-2 rounded-md text-[10px] md:text-xs font-medium transition-all text-center border border-transparent whitespace-nowrap ${
                      isActive
                        ? (isDark ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-400 shadow-[0_0_10px_rgba(99,102,241,0.2)]' : 'bg-indigo-100 border-indigo-200 text-indigo-700 shadow-sm')
                        : `${buttonBg} ${isDark ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-black'}`
                    }`}
                  >
                    {t.layouts[labelKey]}
                  </button>
                );
              })}
            </div>
        </div>
      </div>
    </div>
  );
});
