// @google/genai coding guidelines followed: Using React and Three.js components.
import React, { useMemo, useRef, useEffect, useLayoutEffect, useState, Suspense } from 'react';
import '../types'; 
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import type { ShapeType, CharData } from '../types';
import { StellaVerseLayer, PerfectStella, StellaHalf } from './StellaSystem';
import { CharTexturePlane } from './CharTexturePlane';
import { genesisData } from '../data/genesis';
import { getPolyhedronStatus } from '../geometry';

const SphereHalf = React.lazy(() => import('./SphereSystem'));

interface CubeMatrixProps {
  cubeColor: string;
  splitState: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7;
  showText: boolean;
  isTransparent: boolean;
  showLattice: boolean; 
  currentShape: ShapeType;
  gapSize: number;
  verticalSpread: number;
  useMultiColor: boolean; 
  fontLoaded: boolean; 
  selectedFont: string; 
  isBold: boolean; 
  highlightLayer: number;
  textOffset?: number;
  showHalfStella?: boolean;
  theme?: 'dark' | 'light';
}

const exodus19 = "וַיִּסַּע מַלְאַךְ הָאֱלֹהִים הַהֹלֵךְ לִפְנֵי מַחֲנֵה יִשְׂרָאֵל וַיֵּלֶךְ מֵאַחֲרֵיהֶם וַיִּסַּע עַמּוּד הֶעָנָן מִפְּנֵיהֶם וַיַּעֲמֹד מֵאַחֲרֵיהֶם";
const exodus20 = "וַיָּבֹא בֵּין מַחֲנֵה מִצְרַיִם וּבֵין מַחֲנֵה יִשְׂרָאֵל וַיְהִי הֶעָנָן וְהַחֹשֶׁךְ וַיָּאֶר אֶת הַלָּיְלָה וְלֹא קָרַב זֶה אֶל זֶה כָּל הַלָּיְלָה";
const exodus21 = "וַיֵּט מֹשֶׁה אֶת יָדוֹ עַל הַיָּם וַיּוֹלֶךְ יְהוָה אֶת הַיָּם בְּרוּחַ קָדִים עַזָּה כָּל הַלַּיְלָה וַיָּשֶׂם אֶת הַיָּם לֶחָרָבָה וַיִּבָּקְעוּ הַמָּיִם";

const stripNikud = (str: string) => str.replace(/[\u0591-\u05C7]/g, "").replace(/\s/g, "");

const getChars = (text: string) => text.split('');
const sofitToRegular: Record<string, string> = { 'ך': 'כ', 'מ': 'ם', 'נ': 'ן', 'פ': 'ף', 'צ': 'ץ' };
const toRegular = (char: string) => sofitToRegular[char] || char;
const regularToSofit: Record<string, string> = { 'כ': 'ך', 'מ': 'ם', 'נ': 'ן', 'פ': 'ף', 'צ': 'ץ' };
const toSofit = (char: string) => regularToSofit[char] || char;

const lightenColor = (color: string, percent: number) => {
    const num = parseInt(color.replace("#", ""), 16),
        amt = Math.round(2.55 * percent * 100),
        R = (num >> 16) + amt,
        G = (num >> 8 & 0x00FF) + amt,
        B = (num & 0x0000FF) + amt;
    return "#" + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 + (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 + (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
};

const splitVerseRowByRow = (data: CharData[]) => {
    const rightHalf: CharData[] = [];
    const leftHalf: CharData[] = [];
    const emptyChar: CharData = { char: '', originalChar: '', color: '#ffffff' };
    for (let r = 0; r < 6; r++) {
        const rowStart = r * 12;
        for (let c = 0; c < 6; c++) rightHalf.push(data[rowStart + c] || emptyChar);
        for (let c = 6; c < 12; c++) leftHalf.push(data[rowStart + c] || emptyChar);
    }
    return { right: rightHalf, left: leftHalf };
};

const splitVerseReverse = (data: CharData[]) => {
    const rightHalf: CharData[] = []; 
    const leftHalf: CharData[] = [];
    const emptyChar: CharData = { char: '', originalChar: '', color: '#ffffff' };
    for (let r = 0; r < 6; r++) {
        const textRow = 5 - r;
        const rowStart = textRow * 12;
        const leftChunk: CharData[] = [];
        const rightChunk: CharData[] = [];
        for (let c = 0; c < 6; c++) leftChunk.push(data[rowStart + c] || emptyChar);
        for (let c = 6; c < 12; c++) rightChunk.push(data[rowStart + c] || emptyChar);
        leftChunk.reverse();
        rightChunk.reverse();
        leftHalf.push(...leftChunk);
        rightHalf.push(...rightChunk);
    }
    return { right: rightHalf, left: leftHalf };
};

const noiseCache: Record<string, THREE.CanvasTexture> = {};

const sharedBoxMeshGeometry = new THREE.BoxGeometry(0.998, 0.998, 0.998); 
const sharedBoxEdgesGeometry = new THREE.EdgesGeometry(new THREE.BoxGeometry(1, 1, 1));

const getNoiseTexture = (baseColorHex: string) => {
    if (noiseCache[baseColorHex]) return noiseCache[baseColorHex];
    const size = 512;
    const canvas = document.createElement('canvas');
    canvas.width = size; canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (ctx) {
        ctx.fillStyle = baseColorHex;
        ctx.fillRect(0,0,size,size);
        const c = new THREE.Color(baseColorHex);
        const brightness = (c.r * 299 + c.g * 587 + c.b * 114) / 1000;
        const isDark = brightness < 0.5;
        const noiseCount = 15000;
        for(let i=0; i<noiseCount; i++) {
            const x = Math.random() * size;
            const y = Math.random() * size;
            if (isDark) {
                const v = Math.floor(Math.random() * 100 + 155);
                ctx.fillStyle = `rgba(${v},${v},${v}, 0.1)`;
            } else {
                const r = Math.floor(Math.random() * 255);
                ctx.fillStyle = `rgba(${r},${r},${r}, 0.05)`;
            }
            const dotSize = Math.random() < 0.5 ? 1 : 2;
            ctx.fillRect(x,y,dotSize,dotSize);
        }
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(1, 1); 
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 4;
    noiseCache[baseColorHex] = tex;
    return tex;
};


const SixSidedChar: React.FC<{
  charData: CharData;
  position: [number, number, number];
  cubeColor: string;
  useMultiColor: boolean;
  isRightBlock?: boolean;
  fontLoaded: boolean;
  isEngraved: boolean;
  selectedFont: string;
  isBold: boolean;
  splitState: number;
  layerIndex: number;
  v21Color: string; 
  v19Color: string;
  v20Color: string;
  rotation?: [number, number, number];
  scale?: [number, number, number];
}> = React.memo(({ charData, position, cubeColor, useMultiColor, isRightBlock = false, fontLoaded, isEngraved, selectedFont, isBold, splitState, layerIndex, v21Color, v19Color, v20Color, rotation = [0,0,0], scale = [1,1,1] }) => {
  const o = 0.501; 
  let additionalRot = 0;
  if (splitState === 5 || splitState === 6) additionalRot = Math.PI * 1.5;
  const bottomRot = (Math.PI * 1.5) + additionalRot + (isRightBlock ? Math.PI : 0);

  const faces = useMemo(() => [
      { pos: [o, 0, 0], rot: [0, Math.PI / 2, 0], scale: [1, 1, 1] },     
      { pos: [-o, 0, 0], rot: [0, -Math.PI / 2, 0], scale: [1, 1, 1] },   
      { pos: [0, o, 0], rot: [-Math.PI / 2, 0, Math.PI + (isRightBlock ? Math.PI : 0)], scale: [1, 1, 1] }, 
      { pos: [0, -o, 0], rot: [Math.PI / 2, 0, bottomRot], scale: [1, 1, 1] },  
      { pos: [0, 0, o], rot: [0, 0, 0], scale: [1, 1, 1] },               
      { pos: [0, 0, -o], rot: [0, Math.PI, 0], scale: [-1, 1, 1] },        
  ], [isRightBlock, bottomRot]);

  const effectiveColor = useMultiColor ? charData.color : undefined;

  return (
      <group position={position} rotation={rotation} scale={scale}>
          {faces.map((f, i) => {
               let displayChar = charData.char;
               let faceBackgroundColor: string | undefined = undefined;
               
               if (splitState === 5) {
                   if (i === 0 || i === 1 || i === 4 || i === 5) displayChar = charData.originalChar || charData.char;
                   else if (i === 3) {
                       const isFrontBoard = (layerIndex === 2 || layerIndex === 3);
                       if (isFrontBoard) {
                           displayChar = toSofit(charData.char);
                           faceBackgroundColor = '#ffff00';
                       } else displayChar = toRegular(charData.originalChar);
                   }
               } else if (splitState === 6) {
                   if (i === 3) {
                       const isFrontBoard = (layerIndex === 2 || layerIndex === 3);
                       if (isFrontBoard) {
                            faceBackgroundColor = '#ffff00';
                            displayChar = toSofit(charData.char);
                       } else {
                           const isV21 = charData.color === v21Color;
                           const isV19orV20 = charData.color === v19Color || charData.color === v20Color;
                           if (isV21) displayChar = charData.forceRegular ? toRegular(charData.char) : toSofit(charData.char);
                           else if (isV19orV20) displayChar = toRegular(charData.char);
                           else displayChar = charData.char;
                       }
                   }
               }
               return (
                   <CharTexturePlane key={i} char={displayChar} textColor={effectiveColor} backgroundColor={faceBackgroundColor} position={f.pos as [number, number, number]} rotation={f.rot as [number, number, number]} scale={f.scale as [number, number, number]} cubeColor={cubeColor} fontLoaded={fontLoaded} isEngraved={isEngraved} selectedFont={selectedFont} isBold={isBold} />
               );
          })}
      </group>
  );
});


const VerseLayer: React.FC<{ chars: CharData[]; layerIndex: number; cubeColor: string; verticalSpread: number; useMultiColor: boolean; fontLoaded: boolean; isEngraved: boolean; selectedFont: string; isBold: boolean; splitState: number; gridSize?: number; rows?: number; cols?: number; v19Color: string; v20Color: string; v21Color: string; }> = React.memo(({ chars, layerIndex, cubeColor, verticalSpread, useMultiColor, fontLoaded, isEngraved, selectedFont, isBold, splitState, gridSize = 6, rows, cols, v19Color, v20Color, v21Color }) => {
  const isRightBlock = layerIndex >= 3;
  const numRows = rows || gridSize;
  const numCols = cols || gridSize;
  const centerOffsetY = (numRows - 1) / 2;
  const centerOffsetX = (numCols - 1) / 2;
  return (
    <group>
      {chars.map((charData, i) => {
        if (i >= numRows * numCols) return null;
        const row = Math.floor(i / numCols);
        const col = i % numCols;
        const y = (centerOffsetY - row) * verticalSpread;
        const z = -centerOffsetX + col; 
        return (
          <SixSidedChar key={`${layerIndex}-${i}`} charData={charData} position={[0, y, z]} cubeColor={cubeColor} useMultiColor={useMultiColor} isRightBlock={isRightBlock} fontLoaded={fontLoaded} isEngraved={isEngraved} selectedFont={selectedFont} isBold={isBold} splitState={splitState} layerIndex={layerIndex} v19Color={v19Color} v20Color={v20Color} v21Color={v21Color} />
        );
      })}
    </group>
  );
});


const LayerLattice: React.FC<{ cubeColor: string; verticalSpread: number; layerIndex: number; currentShape: ShapeType; showHalfStella?: boolean; theme?: 'dark' | 'light' }> = React.memo(({ cubeColor, verticalSpread, layerIndex, currentShape, showHalfStella, theme = 'dark' }) => {
    const pointsMeshRef = useRef<THREE.InstancedMesh>(null);
    const dummy = useMemo(() => new THREE.Object3D(), []);
    const gridSize = 6;
    const centerOffset = (gridSize - 1) / 2; 
    const rowLineGeometry = useMemo(() => new THREE.EdgesGeometry(new THREE.BoxGeometry(1, 1, gridSize)), [gridSize]);
    
    const pointSize = 0.07; 
    const sphereGeom = useMemo(() => new THREE.SphereGeometry(pointSize, 16, 16), [pointSize]); 
    const texture = useMemo(() => getNoiseTexture('#ffffff'), []);
    
    useLayoutEffect(() => {
        if (!pointsMeshRef.current) return;
        let idx = 0;
        
        const goldC = new THREE.Color(theme === 'dark' ? '#ffd700' : '#eab308');
        const blueC = new THREE.Color('#0000cc'); 
        const redC = new THREE.Color('#ff0000');

        const cells = 6; 
        const cellCenterOffset = (cells - 1) / 2; 
        for(let r=0; r<cells; r++) {
             const localY = (-cellCenterOffset + r) * verticalSpread; 
             for(let c=0; c<cells; c++) {
                 const localZ = -cellCenterOffset + c; 
                 const offsets = [[-0.5, -0.5, -0.5], [0.5, -0.5, -0.5], [-0.5, 0.5, -0.5], [0.5, 0.5, -0.5], [-0.5, -0.5, 0.5], [0.5, -0.5, 0.5], [-0.5, 0.5, 0.5], [0.5, 0.5, 0.5]];
                 for (const offset of offsets) {
                     const [ox, oy, oz] = offset;
                     const ix = Math.round((-cellCenterOffset + layerIndex) + ox);
                     const iy = Math.round((-cellCenterOffset + r) + oy);
                     const iz = Math.round((-cellCenterOffset + c) + oz);
                     
                     let isBlue = false;
                     if (currentShape === 'sphere') {
                          const d2 = ix*ix + iy*iy + iz*iz;
                          if (d2 === 9) isBlue = true;
                     } else if (currentShape === 'octahedron') {
                          if (Math.abs(ix) + Math.abs(iy) + Math.abs(iz) === 3) isBlue = true;
                     } else if (currentShape === 'stella') {
                          const s1 = ix + iy + iz, s2 = ix - iy - iz, s3 = -ix + iy - iz, s4 = -ix - iy + iz;
                          const onT1 = (s1 === -3 || s2 === -3 || s3 === -3 || s4 === -3);
                          const onT2 = (s1 === 3 || s2 === 3 || s3 === 3 || s4 === 3);
                          if (showHalfStella) { 
                              if (onT1) isBlue = true; 
                          } else { 
                              if (onT1 || onT2) isBlue = true; 
                          }
                     } else if (currentShape === 'dodecahedron') {
                         const status = getPolyhedronStatus(ix, iy, iz, 'dodeca');
                         if (status === 'touching') isBlue = true;
                     } else if (currentShape === 'icosahedron') {
                         const status = getPolyhedronStatus(ix, iy, iz, 'ico');
                         if (status === 'touching') isBlue = true;
                     }
                     
                     dummy.position.set(ox, localY + oy, localZ + oz);
                     dummy.scale.setScalar(1); 
                     dummy.updateMatrix();
                     pointsMeshRef.current.setMatrixAt(idx, dummy.matrix);
                     
                     if (ix === 0 && iy === 0 && iz === 0) {
                         pointsMeshRef.current.setColorAt(idx, redC);
                     } else {
                         pointsMeshRef.current.setColorAt(idx, isBlue ? blueC : goldC);
                     }
                     idx++;
                 }
             }
        }
        pointsMeshRef.current.instanceMatrix.needsUpdate = true;
        if (pointsMeshRef.current.instanceColor) pointsMeshRef.current.instanceColor.needsUpdate = true;
    }, [dummy, verticalSpread, currentShape, layerIndex, showHalfStella, theme]);

    const lineColor = theme === 'dark' ? 'white' : 'black';

    return (
        <group>
             {Array.from({length: gridSize}).map((_, i) => (
                 <group key={i} position={[0, (-centerOffset + i) * verticalSpread, 0]}>
                     <lineSegments geometry={rowLineGeometry}>
                        <lineBasicMaterial color={lineColor} transparent opacity={0.15} depthWrite={false} />
                     </lineSegments>
                 </group>
             ))}
             <instancedMesh ref={pointsMeshRef} args={[sphereGeom, undefined, 288]}>
                <meshStandardMaterial map={texture} bumpMap={texture} bumpScale={0.05} metalness={0.7} roughness={0.1} envMapIntensity={2.0} transparent={false} opacity={1.0} />
            </instancedMesh>
        </group>
    );
});

const PerfectOctahedron: React.FC<{ color: string; isTransparent: boolean; }> = ({ color, isTransparent }) => {
  const geometry = useMemo(() => new THREE.OctahedronGeometry(3.0, 0), []);
  return (
    <group>
      <mesh castShadow receiveShadow geometry={geometry}>
        <meshPhysicalMaterial color={color} roughness={0.05} metalness={0.2} transparent={isTransparent} opacity={isTransparent ? 0.3 : 1.0} transmission={isTransparent ? 0.6 : 0} thickness={2.0} depthWrite={!isTransparent} side={isTransparent ? THREE.DoubleSide : THREE.FrontSide} envMapIntensity={2.0} />
      </mesh>
      <lineSegments>
         <edgesGeometry args={[geometry]} />
         <lineBasicMaterial color={isTransparent ? "#ffffff" : "#ffffff"} transparent opacity={0.4} />
      </lineSegments>
    </group>
  );
};

const PerfectDodecahedron: React.FC<{ color: string; isTransparent: boolean; }> = ({ color, isTransparent }) => {
  const geometry = useMemo(() => new THREE.DodecahedronGeometry(3.215, 0), []);
  return (
    <group>
      <mesh castShadow receiveShadow geometry={geometry}>
        <meshPhysicalMaterial color={color} roughness={0.05} metalness={0.2} transparent={isTransparent} opacity={isTransparent ? 0.3 : 1.0} transmission={isTransparent ? 0.6 : 0} thickness={2.0} depthWrite={!isTransparent} side={isTransparent ? THREE.DoubleSide : THREE.FrontSide} envMapIntensity={2.0} />
      </mesh>
      <lineSegments>
         <edgesGeometry args={[geometry]} />
         <lineBasicMaterial color={isTransparent ? "#ffffff" : "#ffffff"} transparent opacity={0.4} />
      </lineSegments>
    </group>
  );
};

const PerfectIcosahedron: React.FC<{ color: string; isTransparent: boolean; }> = ({ color, isTransparent }) => {
  // Correct mathematical radius for Icosahedron inscribed in Cube 6 is ~3.527
  const geometry = useMemo(() => new THREE.IcosahedronGeometry(3.527, 0), []);
  return (
    <group>
      <mesh castShadow receiveShadow geometry={geometry}>
        <meshPhysicalMaterial color={color} roughness={0.05} metalness={0.2} transparent={isTransparent} opacity={isTransparent ? 0.3 : 1.0} transmission={isTransparent ? 0.6 : 0} thickness={2.0} depthWrite={!isTransparent} side={isTransparent ? THREE.DoubleSide : THREE.FrontSide} envMapIntensity={2.0} />
      </mesh>
      <lineSegments>
         <edgesGeometry args={[geometry]} />
         <lineBasicMaterial color={isTransparent ? "#ffffff" : "#ffffff"} transparent opacity={0.4} />
      </lineSegments>
    </group>
  );
};

// --- NEW COMPONENT: PolyhedronHalf for split view ---
const PolyhedronHalf: React.FC<{ 
    side: 'left' | 'right'; 
    color: string; 
    isTransparent: boolean; 
    type: 'dodecahedron' | 'icosahedron' | 'octahedron';
}> = ({ side, color, isTransparent, type }) => {
    const isLeft = side === 'left';
    const meshGroupRef = useRef<THREE.Group>(null);
    const localX = isLeft ? 1.5 : -1.5;
    
    // Clipping plane setup
    const clippingPlane = useMemo(() => {
        const normal = new THREE.Vector3(isLeft ? -1 : 1, 0, 0);
        return new THREE.Plane(normal, 0);
    }, [isLeft]);

    // Update clipping plane every frame to match mesh position perfectly
    useFrame(() => {
        if (meshGroupRef.current) {
            const worldPos = new THREE.Vector3();
            meshGroupRef.current.getWorldPosition(worldPos);
            // Epsilon offset to prevent Z-fighting
            const epsilon = 0.002;
            clippingPlane.constant = isLeft ? (worldPos.x - epsilon) : (-worldPos.x - epsilon);
        }
    });

    const geometry = useMemo(() => {
        if (type === 'octahedron') return new THREE.OctahedronGeometry(3.0, 0);
        // Updated Icosahedron radius to 3.527 to match strict math
        return type === 'dodecahedron' ? new THREE.DodecahedronGeometry(3.215, 0) : new THREE.IcosahedronGeometry(3.527, 0);
    }, [type]);

    const materialFront = useMemo(() => new THREE.MeshPhysicalMaterial({
        color: color, 
        roughness: 0.05, 
        metalness: 0.2,
        clippingPlanes: [clippingPlane], clipShadows: true,
        transparent: isTransparent, 
        opacity: isTransparent ? 0.3 : 1.0,
        transmission: isTransparent ? 0.6 : 0, 
        thickness: 2.0,
        envMapIntensity: 2.0, 
        side: THREE.FrontSide,
        depthWrite: !isTransparent
    }), [color, clippingPlane, isTransparent]);

    // Dark interior material for the cut face illusion
    const materialBack = useMemo(() => new THREE.MeshBasicMaterial({
        color: '#111111', // Very dark grey/black
        clippingPlanes: [clippingPlane],
        side: THREE.BackSide, // Renders on the inside faces
        depthWrite: true
    }), [clippingPlane]);

    // Line material supporting clipping
    const lineMaterial = useMemo(() => new THREE.LineBasicMaterial({
        color: '#ffffff',
        transparent: true,
        opacity: 0.4,
        clippingPlanes: [clippingPlane]
    }), [clippingPlane]);

    return (
        <group position={[localX, 0, 0]} ref={meshGroupRef}>
            <group>
                <mesh castShadow receiveShadow material={materialFront} geometry={geometry} />
                {!isTransparent && (
                    <mesh material={materialBack} geometry={geometry} />
                )}
                <lineSegments geometry={new THREE.EdgesGeometry(geometry)} material={lineMaterial} />
            </group>
        </group>
    );
};


const SingleCube: React.FC<{ position: [number, number, number]; material: THREE.Material; isTransparent: boolean; edgeColor: string; edgeOpacity?: number; }> = ({ position, material, isTransparent, edgeColor, edgeOpacity }) => {
    // Sharp edges for internal structure: 0.45 opacity in transparent mode
    const op = edgeOpacity !== undefined ? edgeOpacity : (isTransparent ? 0.45 : 0.5);
    return (
        <group position={position}>
            <mesh material={material} castShadow receiveShadow={false} geometry={sharedBoxMeshGeometry} />
            <lineSegments geometry={sharedBoxEdgesGeometry}>
                <lineBasicMaterial color={edgeColor} transparent opacity={op} />
            </lineSegments>
        </group>
    );
}

const LayerContent: React.FC<{ layerIndex: number; cubeColor: string; isTransparent: boolean; verticalSpread: number; isBoundingMode?: boolean; gridSize?: number; }> = React.memo(({ layerIndex, cubeColor, isTransparent, verticalSpread, isBoundingMode = false, gridSize = 6 }) => {
  const texture = useMemo(() => getNoiseTexture(cubeColor), [cubeColor]);
  const edgeColor = useMemo(() => {
     if (isBoundingMode || isTransparent) return '#ffffff';
     const c = new THREE.Color(cubeColor);
     return ((c.r*0.299 + c.g*0.587 + c.b*0.114) > 0.5) ? '#000000' : '#ffffff';
  }, [cubeColor, isTransparent, isBoundingMode]);
  
  const material = useMemo(() => {
      if (isTransparent) {
          return new THREE.MeshStandardMaterial({
              color: '#ffffff',
              transparent: true,
              opacity: 0.012, // Even more clear faces to see inside structure
              roughness: 0,
              metalness: 0,
              depthWrite: false, 
              side: THREE.DoubleSide
          });
      } else {
          return new THREE.MeshPhysicalMaterial({
              color: cubeColor,
              map: texture,
              bumpMap: texture,
              bumpScale: 0.02,
              transparent: false,
              opacity: 1.0,
              roughness: 0.4,
              metalness: 0.3,
              transmission: 0, 
              depthWrite: true,
              side: THREE.FrontSide,
              envMapIntensity: 1.0
          });
      }
  }, [isTransparent, cubeColor, texture]); 

  const cubes = useMemo(() => {
      const newCubes = [];
      const centerOffset = (gridSize - 1) / 2; 
      for(let i=0; i<gridSize; i++){
          for(let j=0; j<gridSize; j++){
               const y = (-centerOffset + i) * verticalSpread;
               const z = -centerOffset + j;
               newCubes.push({ id: `${layerIndex}-${i}-${j}`, pos: [0, y, z] as [number, number, number] });
          }
      }
      return newCubes;
  }, [layerIndex, verticalSpread, gridSize]);
  return (
    <group>
        {cubes.map(c => <SingleCube key={c.id} position={c.pos} material={material} isTransparent={isTransparent} edgeColor={edgeColor} edgeOpacity={isBoundingMode ? 0.25 : undefined} />)}
    </group>
  );
});

const BlockWrapper: React.FC<{ side: 'left' | 'right'; splitState: number; gapSize?: number; children: React.ReactNode; currentShape: ShapeType; isTransparent: boolean; cubeColor: string; }> = ({ side, splitState, gapSize = 1.0, children, currentShape, isTransparent, cubeColor }) => {
    const groupRef = useRef<THREE.Group>(null);
    const isLeft = side === 'left';
    const pivotOffset = 3.0; 
    useFrame((state, delta) => {
        if (!groupRef.current) return;
        const safeDelta = Math.min(delta, 0.1);
        let targetX = 0, targetZ = -pivotOffset, targetRotY = 0;
        const baseCenter = isLeft ? -1.5 : 1.5;
        if (splitState === 0) { targetX = baseCenter * gapSize; targetRotY = 0; targetZ = -pivotOffset; } 
        else if (splitState === 1) { targetX = (baseCenter * gapSize) + ((isLeft ? -1.5 : 1.5) * gapSize); targetRotY = 0; targetZ = -pivotOffset; } 
        const safeX = isLeft ? -2.0 : 2.0;  
        if (splitState >= 2) { 
             targetZ = 0;
             const isRotated = Math.abs(groupRef.current.rotation.y) > (Math.PI/2 * 0.95);
             if (!isRotated) { targetX = safeX; if (Math.abs(groupRef.current.position.x) > 1.8) targetRotY = isLeft ? -Math.PI / 2 : Math.PI / 2; } 
             else { targetX = 0; targetRotY = isLeft ? -Math.PI / 2 : Math.PI / 2; }
        } else { if (Math.abs(groupRef.current.rotation.y) > 0.1) { targetX = safeX; if (Math.abs(groupRef.current.position.x) > 1.8) targetRotY = 0; else targetRotY = isLeft ? -Math.PI / 2 : Math.PI / 2; targetZ = 0; } }
        const alphaPos = Math.min(safeDelta * 12.0, 1.0), alphaRot = Math.min(safeDelta * 8.0, 1.0);
        groupRef.current.position.x = THREE.MathUtils.lerp(groupRef.current.position.x, targetX, alphaPos);
        groupRef.current.position.z = THREE.MathUtils.lerp(groupRef.current.position.z, targetZ, alphaPos);
        groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, targetRotY, alphaRot);
    });
    return (
        <group ref={groupRef}>
            <group position={[0, 0, pivotOffset]}>
                {children}
                {/* Render split halves if needed */}
                {splitState === 1 && (
                    <>
                         {currentShape === 'dodecahedron' && <PolyhedronHalf side={side} color={cubeColor} isTransparent={isTransparent} type="dodecahedron" />}
                         {currentShape === 'icosahedron' && <PolyhedronHalf side={side} color={cubeColor} isTransparent={isTransparent} type="icosahedron" />}
                         {currentShape === 'octahedron' && <PolyhedronHalf side={side} color={cubeColor} isTransparent={isTransparent} type="octahedron" />}
                    </>
                )}
            </group>
        </group>
    );
});

const LayerWrapper: React.FC<{ localIndex: number; gapSize: number; children: React.ReactNode; }> = ({ localIndex, gapSize, children }) => {
    const groupRef = useRef<THREE.Group>(null);
    useFrame((state, delta) => { if(groupRef.current) groupRef.current.position.x = THREE.MathUtils.lerp(groupRef.current.position.x, (localIndex - 1) * gapSize, Math.min(delta * 5.0, 1.0)); });
    useLayoutEffect(() => { if(groupRef.current) groupRef.current.position.x = (localIndex - 1) * gapSize; }, []);
    return <group ref={groupRef}>{children}</group>;
};

const ShapeTransition: React.FC<{ visible: boolean; children: React.ReactNode; scale?: number; }> = ({ visible, children, scale = 1 }) => {
  const ref = useRef<THREE.Group>(null);
  useLayoutEffect(() => { if (ref.current && !visible) { ref.current.scale.setScalar(0.001); ref.current.visible = false; } }, []);
  useFrame((state, delta) => { if (ref.current) { const targetScale = visible ? scale : 0.001; const speed = 6.0 * delta; ref.current.scale.x = THREE.MathUtils.lerp(ref.current.scale.x, targetScale, speed); ref.current.scale.y = THREE.MathUtils.lerp(ref.current.scale.y, targetScale, speed); ref.current.scale.z = THREE.MathUtils.lerp(ref.current.scale.z, targetScale, speed); if (ref.current.scale.x < 0.01 && !visible) ref.current.visible = false; else ref.current.visible = true; } });
  return <group ref={ref}>{children}</group>;
};

const GenesisSystem: React.FC<{ gapSize: number; cubeColor: string; fontLoaded: boolean; selectedFont: string; isBold: boolean; }> = ({ gapSize, cubeColor, fontLoaded, selectedFont, isBold }) => {
    const gridSize = 7, offset = (gridSize - 1) / 2;
    return (
        <group>
            {(genesisData || []).slice(0, 343).map((data, i) => {
                const layer = Math.floor(i / (gridSize * gridSize)), rem = i % (gridSize * gridSize), row = Math.floor(rem / gridSize), col = rem % gridSize;
                
                // Index 171 is the exact center of 343 (0..342)
                const isCenter = i === 171;
                const effectiveColor = isCenter ? '#ff0000' : cubeColor;

                return <SixSidedChar key={i} charData={data} position={[(col - offset) * gapSize, (offset - row) * gapSize, (layer - offset) * gapSize]} cubeColor={effectiveColor} useMultiColor={false} fontLoaded={fontLoaded} isEngraved={false} selectedFont={selectedFont} isBold={isBold} splitState={0} layerIndex={layer} v19Color="" v20Color="" v21Color="" />;
            })}
        </group>
    )
}

const VoxelSystem: React.FC<CubeMatrixProps> = React.memo((props) => {
    const { cubeColor, splitState, showText, isTransparent, showLattice, currentShape, gapSize, verticalSpread, useMultiColor, fontLoaded, selectedFont, isBold, highlightLayer, showHalfStella, theme = 'dark' } = props;
    const v19C = '#000040', v20C = '#b00000', v21C = '#7e22ce';
    const { v1Parts, v2Parts, v3Parts, panelCharsState6, vInterleavedFwd1Parts, vInterleavedFwd2Parts, vInterleavedFwd3Parts } = useMemo(() => {
        const v1 = stripNikud(exodus19), v2 = stripNikud(exodus20), v3 = stripNikud(exodus21);
        const v1Data: CharData[] = getChars(v1).map(c => ({ char: toRegular(c), originalChar: c, color: v19C }));
        const v2Data: CharData[] = getChars(v2).map(c => ({ char: toRegular(c), originalChar: c, color: v20C }));
        const v3Data: CharData[] = getChars(v3).map(c => ({ char: toSofit(c), originalChar: c, color: v21C }));
        const triplets: CharData[] = [];
        for(let i=0; i<72; i++) {
            const c1 = v1Data[i], c2 = v2Data[71 - i], c3 = v3Data[i];
            triplets.push({ char: c1.char, originalChar: c1.originalChar, color: c1.color });
            triplets.push({ char: i === 41 ? toRegular(c2.char) : c2.char, originalChar: c2.originalChar, color: c2.color }); 
            triplets.push({ char: i === 41 ? toRegular(c3.char) : c3.char, originalChar: c3.originalChar, color: c3.color, forceRegular: i === 41 });
        }
        const panelChars6: CharData[][] = [[], [], [], [], [], []];
        for(let p=0; p<6; p++) { for(let t=0; t<12; t++) { const idx = (p * 12 + t) * 3; if (idx < triplets.length) { panelChars6[p].push(triplets[idx], triplets[idx+1], triplets[idx+2]); } } }
        const allInter = []; for (let i = 0; i < 72; i++) allInter.push(v1Data[i], v2Data[i], v3Data[i]);
        return { v1Parts: splitVerseRowByRow(v1Data), v2Parts: splitVerseReverse(v2Data), v3Parts: splitVerseRowByRow(v3Data), panelCharsState6: panelChars6, vInterleavedFwd1Parts: splitVerseRowByRow(allInter.slice(0, 72)), vInterleavedFwd2Parts: splitVerseRowByRow(allInter.slice(72, 144)), vInterleavedFwd3Parts: splitVerseRowByRow(allInter.slice(144, 216)) };
    }, [v19C, v20C, v21C]);

    const isStyleBounding = (currentShape === 'stella' || currentShape === 'octahedron' || currentShape === 'sphere' || currentShape === 'dodecahedron' || currentShape === 'icosahedron') && splitState !== 1;
    const effectiveSplitState = (currentShape === 'sphere' || currentShape === 'stella' || currentShape === 'octahedron' || currentShape === 'dodecahedron' || currentShape === 'icosahedron') && splitState === 1 ? 1 : (isStyleBounding ? 0 : splitState);
    
    // Removed forced transparency for bounding shapes to allow opaque split views
    const effectiveIsTransparent = isTransparent;
    
    const isBoundingModeRender = currentShape === 'sphere' || currentShape === 'stella' || currentShape === 'octahedron' || currentShape === 'dodecahedron' || currentShape === 'icosahedron';
    const effectiveCubeColor = (currentShape === 'boards' && !isTransparent && !isBoundingModeRender) ? lightenColor(cubeColor, 0.35) : cubeColor;

    // --- FONT OVERRIDE LOGIC ---
    // If we are in "boards" mode, force "Shofar" and Bold. Otherwise use selected settings.
    const isBoards = currentShape === 'boards';
    const effectiveFont = isBoards ? 'Shofar' : selectedFont;
    const effectiveBold = isBoards ? true : isBold;

    const renderLayer = (i: number) => {
        let verseChars: CharData[] = [];
        if (effectiveSplitState === 4) { if (i === 2 || i === 3) verseChars = i === 3 ? v1Parts.right : v1Parts.left; else if (i === 1 || i === 4) verseChars = i === 4 ? v2Parts.right : v2Parts.left; else if (i === 0 || i === 5) verseChars = i === 5 ? v3Parts.right : v3Parts.left; } 
        else if (effectiveSplitState === 5) { if (i === 2 || i === 3) verseChars = i === 3 ? v3Parts.right : v3Parts.left; else if (i === 1 || i === 4) verseChars = i === 4 ? v2Parts.right : v2Parts.left; else if (i === 0 || i === 5) verseChars = i === 5 ? v1Parts.right : v1Parts.left; } 
        else if (effectiveSplitState === 6) { const map = [5, 4, 3, 0, 1, 2]; verseChars = panelCharsState6[map[i]]; } 
        else if (effectiveSplitState === 7) { if (i === 2 || i === 3) verseChars = i === 3 ? vInterleavedFwd1Parts.right : vInterleavedFwd1Parts.left; else if (i === 1 || i === 4) verseChars = i === 4 ? vInterleavedFwd2Parts.right : vInterleavedFwd2Parts.left; else if (i === 0 || i === 5) verseChars = i === 5 ? vInterleavedFwd3Parts.right : vInterleavedFwd3Parts.left; }
        if (effectiveSplitState >= 2 && i >= 3 && verseChars.length > 0) { const newChars = []; for(let r=0; r<6; r++) { newChars.push(...verseChars.slice(r*6, (r+1)*6).reverse()); } verseChars = newChars; }
        return (
            <React.Fragment key={i}>
                {((currentShape === 'stella' || currentShape === 'octahedron' || currentShape === 'dodecahedron' || currentShape === 'icosahedron') ? showLattice : currentShape !== 'genesis') && <LayerContent key={`${i}-${currentShape}-${effectiveIsTransparent ? 'trans' : 'solid'}`} layerIndex={i} cubeColor={isBoundingModeRender ? '#ffffff' : effectiveCubeColor} isTransparent={isBoundingModeRender ? true : effectiveIsTransparent} verticalSpread={verticalSpread} isBoundingMode={isBoundingModeRender} gridSize={6} />}
                {showLattice && <LayerLattice cubeColor={cubeColor} verticalSpread={verticalSpread} layerIndex={i} currentShape={currentShape} showHalfStella={showHalfStella} theme={theme} />}
                {!isBoundingModeRender && effectiveSplitState >= 4 && effectiveSplitState <= 7 && verseChars.length > 0 && <VerseLayer chars={verseChars} layerIndex={i} cubeColor={effectiveCubeColor} verticalSpread={verticalSpread} useMultiColor={useMultiColor} fontLoaded={fontLoaded} isEngraved={currentShape === 'boards'} selectedFont={effectiveFont} isBold={effectiveBold} splitState={effectiveSplitState} v19Color={v19C} v20Color={v20C} v21Color={v21C} />}
            </React.Fragment>
        );
    };

    return (
        <group>
            {currentShape === 'genesis' && <GenesisSystem gapSize={gapSize} cubeColor={cubeColor} fontLoaded={fontLoaded} selectedFont={selectedFont} isBold={isBold} />}
            {currentShape === 'stella' && effectiveSplitState !== 1 && <StellaVerseLayer cubeColor={cubeColor} fontLoaded={fontLoaded} selectedFont={selectedFont} isBold={isBold} showHalfStella={showHalfStella} />}
            {currentShape !== 'genesis' && (
                <group>
                    <BlockWrapper side="left" splitState={effectiveSplitState} gapSize={gapSize} currentShape={currentShape} isTransparent={effectiveIsTransparent} cubeColor={cubeColor}>
                        {[0, 1, 2].map((layerIndex, localIndex) => <LayerWrapper key={layerIndex} localIndex={localIndex} gapSize={effectiveSplitState === 1 ? 1.0 : gapSize}>{renderLayer(layerIndex)}</LayerWrapper>)}
                        {currentShape === 'sphere' && <Suspense fallback={null}><SphereHalf side="left" color={cubeColor === '#e0e0e0' ? '#dc2626' : cubeColor} /></Suspense>}
                        {currentShape === 'stella' && effectiveSplitState === 1 && <StellaHalf side="left" color={cubeColor} isTransparent={effectiveIsTransparent} showHalfStella={showHalfStella} gapSize={gapSize} />}
                    </BlockWrapper>
                    <BlockWrapper side="right" splitState={effectiveSplitState} gapSize={gapSize} currentShape={currentShape} isTransparent={effectiveIsTransparent} cubeColor={cubeColor}>
                        {[3, 4, 5].map((layerIndex, localIndex) => <LayerWrapper key={layerIndex} localIndex={localIndex} gapSize={effectiveSplitState === 1 ? 1.0 : gapSize}>{renderLayer(layerIndex)}</LayerWrapper>)}
                        {currentShape === 'sphere' && <Suspense fallback={null}><SphereHalf side="right" color={cubeColor === '#e0e0e0' ? '#dc2626' : cubeColor} /></Suspense>}
                        {currentShape === 'stella' && effectiveSplitState === 1 && <StellaHalf side="right" color={cubeColor} isTransparent={effectiveIsTransparent} showHalfStella={showHalfStella} gapSize={gapSize} />}
                    </BlockWrapper>
                </group>
            )}
        </group>
    );
});

export const CubeMatrix: React.FC<CubeMatrixProps> = (props) => {
  return (
    <group>
      <ShapeTransition visible={props.currentShape === 'stella' && props.splitState !== 1}><PerfectStella color={props.cubeColor} isTransparent={props.isTransparent} showHalfStella={props.showHalfStella} /></ShapeTransition>
      <ShapeTransition visible={props.currentShape === 'octahedron' && props.splitState !== 1}><PerfectOctahedron color={props.cubeColor} isTransparent={props.isTransparent} /></ShapeTransition>
      <ShapeTransition visible={props.currentShape === 'dodecahedron' && props.splitState !== 1}><PerfectDodecahedron color={props.cubeColor} isTransparent={props.isTransparent} /></ShapeTransition>
      <ShapeTransition visible={props.currentShape === 'icosahedron' && props.splitState !== 1}><PerfectIcosahedron color={props.cubeColor} isTransparent={props.isTransparent} /></ShapeTransition>
      <VoxelSystem {...props} />
    </group>
  );
};
