
const PHI = 1.61803398875;

const normalize = (x: number, y: number, z: number) => {
    const len = Math.sqrt(x * x + y * y + z * z);
    return { x: x / len, y: y / len, z: z / len };
};

// Icosahedron Normals (Face normals of Icosahedron = Vertices of Dual Dodecahedron)
// Matches Three.js IcosahedronGeometry standard orientation.
// Normals are (±1, ±1, ±1) and cyclic permutations of (0, phi, 1/phi).
export const ICO_NORMALS = [
    // (±1, ±1, ±1)
    ...[1, -1].flatMap(x => [1, -1].flatMap(y => [1, -1].map(z => [x, y, z]))),
    // Cyclic permutations of (0, phi, 1/phi) -> (0, 1.618, 0.618)
    ...[1, -1].flatMap(a => [1, -1].map(b => [0, a * PHI, b / PHI])),
    ...[1, -1].flatMap(a => [1, -1].map(b => [b / PHI, 0, a * PHI])),
    ...[1, -1].flatMap(a => [1, -1].map(b => [a * PHI, b / PHI, 0]))
].map(([x, y, z]) => normalize(x, y, z));

// Dodecahedron Normals (Face normals of Dodecahedron = Vertices of Dual Icosahedron)
// Matches Three.js DodecahedronGeometry.
// Standard orientation normals are cyclic permutations of (0, phi, 1).
export const DODECA_NORMALS = [
    // Cyclic permutations of (0, phi, 1)
    ...[1, -1].flatMap(a => [1, -1].map(b => [0, a * PHI, b])),
    ...[1, -1].flatMap(a => [1, -1].map(b => [b, 0, a * PHI])),
    ...[1, -1].flatMap(a => [1, -1].map(b => [a * PHI, b, 0]))
].map(([x, y, z]) => normalize(x, y, z));

export function getPolyhedronStatus(x: number, y: number, z: number, type: 'dodeca' | 'ico') {
    const normals = type === 'ico' ? ICO_NORMALS : DODECA_NORMALS;
    
    // STRICT MATHEMATICAL LIMITS
    // --------------------------
    // Icosahedron: 
    // Vertices scaled to max coord 3 implies Inradius (Face Dist) = 3 * phi / sqrt(3) ≈ 2.8025.
    // Point (3,0,0) projected on normal (phi, 1/phi, 0) gives exactly this value.
    const ICO_LIMIT = 2.8025;
    
    // Dodecahedron:
    // Vertices scaled to max coord 3.
    // Inradius calculation yields approx 2.552.
    const DODECA_LIMIT = 2.552;

    const limit = type === 'ico' ? ICO_LIMIT : DODECA_LIMIT;
    
    let maxProj = 0;
    for (const n of normals) {
        const proj = x * n.x + y * n.y + z * n.z;
        if (proj > maxProj) maxProj = proj;
    }
    
    // Epsilon for floating point comparison only. 
    // No visual padding allowed.
    const EPSILON = 0.02; 
    
    if (maxProj > limit + EPSILON) return 'outside';
    if (maxProj > limit - EPSILON) return 'touching'; // Only strictly touching points
    
    return 'inside';
}
