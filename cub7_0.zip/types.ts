
import * as THREE from 'three';
import React from 'react';

export type ShapeType = 'cube' | 'sphere' | 'stella' | 'octahedron' | 'boards' | 'genesis' | 'dodecahedron' | 'icosahedron';
export type Language = 'en' | 'he' | 'fr';
export type BookType = 'genesis' | 'exodus' | 'leviticus' | 'numbers' | 'deuteronomy';

export interface CharData {
    char: string;
    originalChar: string;
    color?: string;
    forceRegular?: boolean;
    customScale?: number;
}

// Helper type for Three.js elements in JSX
export type ThreeElement<T> = {
  attach?: string;
  args?: any[];
  children?: React.ReactNode;
  ref?: React.Ref<T>;
  key?: React.Key;
  onUpdate?: (self: T) => void;
  dispose?: null;
  object?: any; // For primitive
  castShadow?: boolean;
  receiveShadow?: boolean;
  geometry?: THREE.BufferGeometry;
  material?: THREE.Material | THREE.Material[];
  [key: string]: any; 
};

// Define all Three.js intrinsics in a reusable interface
export interface ThreeIntrinsicElements {
  ambientLight: ThreeElement<THREE.AmbientLight>;
  directionalLight: ThreeElement<THREE.DirectionalLight>;
  pointLight: ThreeElement<THREE.PointLight>;
  group: ThreeElement<THREE.Group>;
  mesh: ThreeElement<THREE.Mesh>;
  lineSegments: ThreeElement<THREE.LineSegments>;
  instancedMesh: ThreeElement<THREE.InstancedMesh>;
  primitive: ThreeElement<any>;
  
  // Geometries
  sphereGeometry: ThreeElement<THREE.SphereGeometry>;
  tetrahedronGeometry: ThreeElement<THREE.TetrahedronGeometry>;
  octahedronGeometry: ThreeElement<THREE.OctahedronGeometry>;
  dodecahedronGeometry: ThreeElement<THREE.DodecahedronGeometry>;
  icosahedronGeometry: ThreeElement<THREE.IcosahedronGeometry>;
  planeGeometry: ThreeElement<THREE.PlaneGeometry>;
  boxGeometry: ThreeElement<THREE.BoxGeometry>;
  edgesGeometry: ThreeElement<THREE.EdgesGeometry>;
  circleGeometry: ThreeElement<THREE.CircleGeometry>;
  
  // Materials
  meshBasicMaterial: ThreeElement<THREE.MeshBasicMaterial>;
  meshStandardMaterial: ThreeElement<THREE.MeshStandardMaterial>;
  meshPhysicalMaterial: ThreeElement<THREE.MeshPhysicalMaterial>;
  lineBasicMaterial: ThreeElement<THREE.LineBasicMaterial>;

  // Misc
  color: ThreeElement<THREE.Color>;
}

// Augment the global JSX namespace (Legacy/Global)
// We merge definitions into IntrinsicElements instead of extending it, 
// to ensure we don't overwrite standard HTML elements.
declare global {
  namespace JSX {
    interface IntrinsicElements {
      ambientLight: ThreeElement<THREE.AmbientLight>;
      directionalLight: ThreeElement<THREE.DirectionalLight>;
      pointLight: ThreeElement<THREE.PointLight>;
      group: ThreeElement<THREE.Group>;
      mesh: ThreeElement<THREE.Mesh>;
      lineSegments: ThreeElement<THREE.LineSegments>;
      instancedMesh: ThreeElement<THREE.InstancedMesh>;
      primitive: ThreeElement<any>;
      
      sphereGeometry: ThreeElement<THREE.SphereGeometry>;
      tetrahedronGeometry: ThreeElement<THREE.TetrahedronGeometry>;
      octahedronGeometry: ThreeElement<THREE.OctahedronGeometry>;
      dodecahedronGeometry: ThreeElement<THREE.DodecahedronGeometry>;
      icosahedronGeometry: ThreeElement<THREE.IcosahedronGeometry>;
      planeGeometry: ThreeElement<THREE.PlaneGeometry>;
      boxGeometry: ThreeElement<THREE.BoxGeometry>;
      edgesGeometry: ThreeElement<THREE.EdgesGeometry>;
      circleGeometry: ThreeElement<THREE.CircleGeometry>;
      
      meshBasicMaterial: ThreeElement<THREE.MeshBasicMaterial>;
      meshStandardMaterial: ThreeElement<THREE.MeshStandardMaterial>;
      meshPhysicalMaterial: ThreeElement<THREE.MeshPhysicalMaterial>;
      lineBasicMaterial: ThreeElement<THREE.LineBasicMaterial>;
      
      color: ThreeElement<THREE.Color>;
    }
  }
}
