
const CACHE_NAME = 'cube-6x6x6-v107'; // Incremented version to force update

// Files to cache immediately on install
// We explicitly list the CDN URLs here so they are downloaded 
// during the "Install" phase, ensuring they are available 
// even if the user goes offline immediately after the first load.
const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/index.tsx', // Ensure entry point is cached
  'https://cdn.tailwindcss.com',
  // Critical Libraries from importmap
  'https://aistudiocdn.com/react@^19.2.0',
  'https://aistudiocdn.com/react-dom@^19.2.0',
  'https://aistudiocdn.com/react-dom@^19.2.0/client',
  'https://aistudiocdn.com/@react-three/fiber@^9.4.0',
  'https://aistudiocdn.com/@react-three/drei@^10.7.7',
  'https://aistudiocdn.com/three@^0.181.2',
  'https://aistudiocdn.com/three-stdlib@^2.36.1',
  // Font assets
  'https://fonts.googleapis.com/css2?family=Rubik:wght@400;700&family=Frank+Ruhl+Libre:wght@700&display=swap'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('Opened cache');
      return cache.addAll(PRECACHE_URLS);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // Skip cross-origin requests for browser extensions etc, but keep CDNs
  if (!event.request.url.startsWith('http')) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }

      return fetch(event.request).then((networkResponse) => {
        // Check if we received a valid response
        if (
          !networkResponse ||
          networkResponse.status !== 200 ||
          networkResponse.type === 'error'
        ) {
          return networkResponse;
        }

        // Clone the response because it's a stream and can only be consumed once
        const responseToCache = networkResponse.clone();

        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, responseToCache);
        });

        return networkResponse;
      }).catch(() => {
        return null;
      });
    })
  );
});
