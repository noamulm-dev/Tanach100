
import React, { useState, Suspense, useEffect, useMemo, useCallback, useRef } from 'react';
import './types'; // Registers global JSX intrinsics for Three.js
import { Canvas } from '@react-three/fiber';
import { Environment, PerspectiveCamera } from '@react-three/drei';
import { CubeMatrix } from './components/CubeMatrix';
import { Controls } from './components/Controls';
import type { ShapeType, Language } from './types';
import * as THREE from 'three';
import { translations } from './translations'; 
import { ZoomFitter, StableOrbitControls } from './components/CameraSystem'; 
import { getPolyhedronStatus } from './geometry';

// --- DATA FOR VERSES AND TRIPLETS ---
const exodus19 = "וַיִּסַּע מַלְאַךְ הָאֱלֹהִים הַהֹלֵךְ לִפְנֵי מַחֲנֵה יִשְׂרָאֵל וַיֵּלֶךְ מֵאַחֲרֵיהֶם וַיִּסַּע עַמּוּד הֶעָנָן מִפְּנֵיהֶם וַיַּעֲמֹד מֵאַחֲרֵיהֶם";
const exodus20 = "וַיָּבֹא בֵּין מַחֲנֵה מִצְרַיִם וּבֵין מַחֲנֵה יִשְׂרָאֵל וַיְהִי הֶעָנָן וְהַחֹשֶׁךְ וַיָּאֶר אֶת הַלָּיְלָה וְלֹא קָרַב זֶה אֶל זֶה כָּל הַלָּיְלָה";
const exodus21 = "וַיֵּט מֹשֶׁה אֶת יָדוֹ עַל הַיָּם וַיּוֹלֶךְ יְהוָה אֶת הַיָּם בְּרוּחַ קָדִים עַזָּה כָּל הַלַּיְלָה וַיָּשֶׂם אֶת הַיָּם לֶחָרָבָה וַיִּבָּקְעוּ הַמָּיִם";

const stripNikud = (str: string) => { return str.replace(/[\u0591-\u05C7]/g, "").replace(/\s/g, ""); };

const regularToSofit: Record<string, string> = { 'כ': 'ך', 'מ': 'ם', 'נ': 'ן', 'פ': 'ף', 'צ': 'ץ' };
const sofitToRegular: Record<string, string> = { 'ך': 'כ', 'ם': 'מ', 'ן': 'נ', 'ף': 'פ', 'ץ': 'צ' };
const toRegular = (char: string) => sofitToRegular[char] || char;
const toSofit = (char: string) => regularToSofit[char] || char;

const versesData = [
    { ref: "שמות י״ד:י״ט", text: exodus19 },
    { ref: "שמות י״ד:כ׳", text: exodus20 },
    { ref: "שמות י״ד:כ״א", text: exodus21 }
];

const AVAILABLE_FONTS = [
    { name: 'Frank Ruhl Libre', label: 'פרנק ריהל' },
    { name: 'Stam', label: 'סת״ם' },
    { name: 'Shofar', label: 'ספר תורה' },
    { name: 'David Libre', label: 'דוד' },
    { name: 'Rubik', label: 'רוביק' },
    { name: 'Heebo', label: 'היבו' },
    { name: 'Amatic SC', label: 'עמתיק' },
    { name: 'Secular One', label: 'סקולר' },
    { name: 'Assistant', label: 'אסיסטנט' },
    { name: 'Varela Round', label: 'עגול' }
];

const fmt = (num: number | null | undefined) => {
    if (num === null || num === undefined) return "";
    return Number.isInteger(num) ? num : Number(num.toFixed(2));
};

interface ShapeSettings {
    colorIdx: number;
    gapSize: number;
    verticalSpread: number;
    splitState: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7;
    highlightLayer: number; 
}

export default function App() {
  const [lang, setLang] = useState<Language>('en'); 
  const [currentShape, setCurrentShape] = useState<ShapeType>('cube'); 
  const [isDebugMode, setIsDebugMode] = useState(false);
  const [fov, setFov] = useState(20); 
  const [showStellaGrid, setShowStellaGrid] = useState(false); 
  const [showHalfStella, setShowHalfStella] = useState(false); 
  
  // Theme State - Default set to Light
  const [theme, setTheme] = useState<'dark' | 'light'>('light');

  // Renamed for clarity: controls the visibility of the stats panel only
  const [isStatsPanelVisible, setIsStatsPanelVisible] = useState(true);
  const [currentVerseIndex, setCurrentVerseIndex] = useState(0);

  // Full Screen State
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Initial settings: Cube starts OPAQUE (colorIdx 0)
  const [shapeSettings, setShapeSettings] = useState<Record<ShapeType, ShapeSettings>>({
      cube: { colorIdx: 0, gapSize: 1.0, verticalSpread: 1.0, splitState: 0, highlightLayer: 0 },
      boards: { colorIdx: 0, gapSize: 1.0, verticalSpread: 1.0, splitState: 5, highlightLayer: 0 }, 
      sphere: { colorIdx: 0, gapSize: 1.0, verticalSpread: 1.0, splitState: 0, highlightLayer: 0 }, 
      stella: { colorIdx: 2, gapSize: 1.0, verticalSpread: 1.0, splitState: 0, highlightLayer: 0 }, 
      octahedron: { colorIdx: 3, gapSize: 1.0, verticalSpread: 1.0, splitState: 0, highlightLayer: 0 },
      dodecahedron: { colorIdx: 2, gapSize: 1.0, verticalSpread: 1.0, splitState: 0, highlightLayer: 0 },
      icosahedron: { colorIdx: 3, gapSize: 1.0, verticalSpread: 1.0, splitState: 0, highlightLayer: 0 },
      genesis: { colorIdx: 0, gapSize: 1.0, verticalSpread: 1.0, splitState: 0, highlightLayer: 0 }
  });

  const defaultSettings: ShapeSettings = { colorIdx: 0, gapSize: 1.0, verticalSpread: 1.0, splitState: 0, highlightLayer: 0 };
  const currentSettings = (shapeSettings && shapeSettings[currentShape]) ? shapeSettings[currentShape] : defaultSettings;
  const colorIdx = currentSettings.colorIdx;
  const gapSize = currentSettings.gapSize;
  const verticalSpread = currentSettings.verticalSpread;
  const splitState = currentSettings.splitState;
  const highlightLayer = currentSettings.highlightLayer;

  // Header height tracking for camera centering
  const headerRef = useRef<HTMLDivElement>(null);
  const [topPanelHeight, setTopPanelHeight] = useState(0);

  useEffect(() => {
    if (!headerRef.current) return;
    
    const observer = new ResizeObserver((entries) => {
      for (let entry of entries) {
        setTopPanelHeight(entry.contentRect.height);
      }
    });
    
    observer.observe(headerRef.current);
    return () => observer.disconnect();
  }, []);

  // Listen for fullscreen changes (e.g. user pressing Escape)
  useEffect(() => {
    const handleFullscreenChange = () => {
        setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const updateSetting = (key: keyof ShapeSettings, value: any) => {
      setShapeSettings(prev => {
          const current = prev[currentShape] || { colorIdx: 0, gapSize: 1.0, verticalSpread: 1.0, splitState: 0, highlightLayer: 0 };
          return {
              ...prev,
              [currentShape]: {
                  ...current,
                  [key]: value
              }
          };
      });
  };

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLangSubmenuOpen, setIsLangSubmenuOpen] = useState(false); 
  const [showVersesModal, setShowVersesModal] = useState(false);
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [showTripletsModal, setShowTripletsModal] = useState(false);
  const [showFontModal, setShowFontModal] = useState(false);
  const [selectedFont, setSelectedFont] = useState('Frank Ruhl Libre'); 
  const [isBold, setIsBold] = useState(false); 
  const [useMultiColor, setUseMultiColor] = useState(true);
  const [fontLoaded, setFontLoaded] = useState(false);
  const [viewOrientation, setViewOrientation] = useState<'iso' | 'top' | 'bottom' | 'front' | 'back' | 'right' | 'left' | 'side'>('iso');
  const [viewTrigger, setViewTrigger] = useState(0);
  
  useEffect(() => {
      const fontStr = '80px "Stam"';
      if (document.fonts.check(fontStr)) {
          setFontLoaded(true);
      } else {
          document.fonts.load(fontStr).then(() => {
              setFontLoaded(true);
          }).catch(() => {
              setFontLoaded(true);
          });
      }
  }, []);

  useEffect(() => {
      if (viewTrigger === 0) {
        setViewOrientation('iso');
        setViewTrigger(t => t + 1);
      }
  }, [viewTrigger]);

  useEffect(() => {
      if (!isMenuOpen) setIsLangSubmenuOpen(false);
  }, [isMenuOpen]);

  const colors = [
      '#e0e0e0', '#eab308', '#38bdf8', '#0ea5e9', '#8b5cf6', '#ffffff'
  ];
  
  const cubeColor = colors[colorIdx];
  const isTransparent = colorIdx === 5; 
  const isTextMode = splitState >= 4 && splitState <= 7;
  const t = translations[lang];

  const handleCycleColor = () => {
    const nextIdx = (colorIdx + 1) % colors.length;
    updateSetting('colorIdx', nextIdx);
  };

  const handleNextVerse = () => {
      setCurrentVerseIndex((prev) => (prev + 1) % versesData.length);
  };

  const handlePrevVerse = () => {
      setCurrentVerseIndex((prev) => (prev - 1 + versesData.length) % versesData.length);
  };

  const handleSetViewOrientation = (o: 'iso' | 'top' | 'bottom' | 'front' | 'back' | 'right' | 'left' | 'side') => {
      setViewOrientation(o);
      setViewTrigger(t => t + 1); 
  };

  const handleSetShape = (newShape: ShapeType) => {
      const shapeToSet = newShape as ShapeType;
      setCurrentShape(shapeToSet);
      setIsMenuOpen(false); 
      setViewOrientation('iso');
      setViewTrigger(t => t + 1);

      if (shapeToSet === 'octahedron' || shapeToSet === 'stella' || shapeToSet === 'dodecahedron' || shapeToSet === 'icosahedron') {
          setShowStellaGrid(true);
      }
  };

  const toggleFullScreen = () => {
    if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch((err) => {
            console.error(`Error attempting to enable full-screen mode: ${err.message} (${err.name})`);
        });
    } else {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        }
    }
  };

  const getMainTitle = () => {
      return t.shapes[currentShape];
  };

  const tripletsData = useMemo(() => {
    const v1 = stripNikud(exodus19);
    const v2 = stripNikud(exodus20);
    const v3 = stripNikud(exodus21);
    const triplets = [];
    for(let i=0; i<72; i++) {
        const c1 = v1[i] || '';
        const c2 = v2[71 - i] || '';
        const c3 = v3[i] || '';
        let finalChar3;
        if (i === 41) { finalChar3 = toRegular(c3); } else { finalChar3 = toSofit(c3); }
        triplets.push({ id: i + 1, char1: toRegular(c1), char2: toRegular(c2), char3: finalChar3 });
    }
    return triplets;
  }, []);

  const stats = useMemo(() => {
      if (currentShape === 'genesis') {
          return { 
              dims: "7×7×7", 
              structure: "Lattice", 
              volume: 343, 
              surface: 0, 
              points: 343, 
              faceBreakdowns: [], 
              totalFacePoints: 0, 
              totalArea: 0, 
              boundingVolume: null, 
              boundingSurface: null, 
              hullPoints: 218 
          };
      }

      if (currentShape === 'sphere' || currentShape === 'stella' || currentShape === 'octahedron' || currentShape === 'dodecahedron' || currentShape === 'icosahedron') {
          let inside = 0;
          let touching = 0;
          let outside = 0;
          const coords = [-3, -2, -1, 0, 1, 2, 3];
          
          for(let x of coords) {
              for(let y of coords) {
                  for(let z of coords) {
                      if (currentShape === 'sphere') {
                          const d2 = x*x + y*y + z*z;
                          if (d2 === 9) touching++;
                          else if (d2 < 9) inside++;
                          else outside++;
                      } else if (currentShape === 'octahedron') {
                          const manhattan = Math.abs(x) + Math.abs(y) + Math.abs(z);
                          if (manhattan === 3) touching++;
                          else if (manhattan < 3) inside++;
                          else outside++;
                      } else if (currentShape === 'dodecahedron') {
                           const status = getPolyhedronStatus(x, y, z, 'dodeca');
                           if (status === 'touching') touching++;
                           else if (status === 'inside') inside++;
                           else outside++;
                      } else if (currentShape === 'icosahedron') {
                           const status = getPolyhedronStatus(x, y, z, 'ico');
                           if (status === 'touching') touching++;
                           else if (status === 'inside') inside++;
                           else outside++;
                      } else {
                          const s1 = x + y + z;
                          const s2 = x - y - z;
                          const s3 = -x + y - z;
                          const s4 = -x - y + z;
                          const inT1 = s1 >= -3 && s2 >= -3 && s3 >= -3 && s4 >= -3;
                          const inT2 = s1 <= 3 && s2 <= 3 && s3 <= 3 && s4 <= 3;
                          if (showHalfStella) {
                              if (inT1) {
                                  const onBoundT1 = (s1 === -3 || s2 === -3 || s3 === -3 || s4 === -3);
                                  if (onBoundT1) touching++;
                                  else inside++;
                              } else outside++;
                          } else {
                              if (inT1 || inT2) {
                                   const onBoundT1 = inT1 && (s1 === -3 || s2 === -3 || s3 === -3 || s4 === -3);
                                   const onBoundT2 = inT2 && (s1 === 3 || s2 === 3 || s3 === 3 || s4 === 3);
                                   if (onBoundT1 || onBoundT2) touching++;
                                   else inside++;
                              } else outside++;
                          }
                      }
                  }
              }
          }

          if (currentShape === 'sphere') {
               return { 
                   dims: "Ø = 6", 
                   structure: "Sphere", 
                   volume: 113.1, 
                   surface: 113.1, 
                   points: inside + touching, 
                   faceBreakdowns: [], 
                   totalFacePoints: 0, 
                   totalArea: 0, 
                   boundingVolume: 216, 
                   boundingSurface: 216,
                   insideCount: inside,
                   touchingCount: touching,
                   outsideCount: outside,
                   totalGridPoints: 343
               };
          } else if (currentShape === 'octahedron') {
               return { 
                   dims: "R = 3", 
                   structure: "Octahedron", 
                   volume: 36, 
                   surface: 36 * Math.sqrt(3), 
                   points: inside + touching, 
                   faceBreakdowns: [], 
                   totalFacePoints: 0, 
                   totalArea: 0, 
                   boundingVolume: 216, 
                   boundingSurface: 216,
                   insideCount: inside,
                   touchingCount: touching,
                   outsideCount: outside,
                   totalGridPoints: 343
               };
          } else if (currentShape === 'dodecahedron') {
                return {
                    dims: "R ≈ 3.22",
                    structure: "Dodecahedron",
                    volume: 92.55, 
                    surface: 108.68, 
                    points: inside + touching,
                    faceBreakdowns: [],
                    totalFacePoints: 0,
                    totalArea: 0,
                    boundingVolume: 216, 
                    boundingSurface: 216,
                    insideCount: inside,
                    touchingCount: touching,
                    outsideCount: outside,
                    totalGridPoints: 343
                };
          } else if (currentShape === 'icosahedron') {
                 return {
                    dims: "R ≈ 3.53",
                    structure: "Icosahedron",
                    volume: 111.55, 
                    surface: 119.30, 
                    points: inside + touching,
                    faceBreakdowns: [],
                    totalFacePoints: 0,
                    totalArea: 0,
                    boundingVolume: 216,
                    boundingSurface: 216,
                    insideCount: inside,
                    touchingCount: touching,
                    outsideCount: outside,
                    totalGridPoints: 343
                };
          } else {
               const smallTriSide = 3 * Math.sqrt(2); 
               const smallTriArea = (Math.sqrt(3) / 4) * Math.pow(smallTriSide, 2); 
               const totalOuterArea = 24 * smallTriArea; 
               const largeTetraEdge = 6 * Math.sqrt(2);
               const largeTetraFaceArea = (Math.sqrt(3) / 4) * Math.pow(largeTetraEdge, 2); 
               const singleTetraArea = 4 * largeTetraFaceArea; 

               return { 
                   dims: "6×6×6 Bound", 
                   structure: showHalfStella ? "Tetrahedron" : "Stella Octangula", 
                   volume: showHalfStella ? 72 : 108, 
                   surface: showHalfStella ? singleTetraArea : totalOuterArea,
                   points: inside + touching, 
                   faceBreakdowns: [], 
                   totalFacePoints: 0, 
                   totalArea: 0, 
                   boundingVolume: 216, 
                   boundingSurface: 216,
                   insideCount: inside,
                   touchingCount: touching,
                   outsideCount: outside,
                   totalGridPoints: 343
               };
          }
      }
      
      if (splitState === 0) return { dims: "6×6×6", structure: "1 (6³)", volume: 216, surface: 216, points: 343, faceBreakdowns: [{ blockDims: "6×6", latticeDims: "7×7", count: 6, area: 36, totalArea: 216, points: 49, totalPoints: 294 }], totalFacePoints: 294, totalArea: 216, hullPoints: 218 };
      else if (splitState === 1) return { dims: "6×6×3", structure: "1 of 2 (6×6×3)", volume: 108, surface: 144, points: 196, faceBreakdowns: [{ blockDims: "6×6", latticeDims: "7×7", count: 2, area: 36, totalArea: 72, points: 49, totalPoints: 98 }, { blockDims: "6×3", latticeDims: "7×4", count: 4, area: 18, totalArea: 72, points: 28, totalPoints: 112 }], totalFacePoints: 210, totalArea: 144, hullPoints: 146 };
      else if (splitState === 2) return { dims: "12×6×3", structure: "1 (12×6×3)", volume: 216, surface: 252, points: 364, faceBreakdowns: [{ blockDims: "12×6", latticeDims: "13×7", count: 2, area: 72, totalArea: 144, points: 91, totalPoints: 182 }, { blockDims: "12×3", latticeDims: "13×4", count: 2, area: 36, totalArea: 72, points: 52, totalPoints: 104 }, { blockDims: "6×3", latticeDims: "7×4", count: 2, area: 18, totalArea: 36, points: 28, totalPoints: 56 }], totalFacePoints: 342, totalArea: 252, hullPoints: 254 };
      
      return { dims: "6×6×6", structure: "1 (6³)", volume: 216, surface: 216, points: 343, faceBreakdowns: [], totalFacePoints: 0, totalArea: 0 };
  }, [currentShape, splitState, showHalfStella]);

  const showStats = !isTextMode; 

  const showLatticeInScene = (currentShape === 'stella' || currentShape === 'octahedron' || currentShape === 'dodecahedron' || currentShape === 'icosahedron') ? showStellaGrid : (currentShape !== 'boards');

  // Theme Colors
  const isDark = theme === 'dark';
  const bgColor = isDark ? 'bg-[#111]' : 'bg-[#f0f2f5]';
  const headerBg = isDark ? 'bg-black/80' : 'bg-white/80';
  const borderColor = isDark ? 'border-white/10' : 'border-black/10';
  const textColor = isDark ? 'text-gray-300' : 'text-gray-700';
  const hoverBg = isDark ? 'hover:bg-white/5' : 'hover:bg-black/5';

  return (
    <div className={`w-full h-full relative ${bgColor} overflow-hidden`} dir={lang === 'he' ? 'rtl' : 'ltr'}>
      <div className="absolute opacity-0 pointer-events-none font-stam text-[1px]">אבגדהוזחטיכלמנסעפצקרשת</div>
      <div className="absolute opacity-0 pointer-events-none font-shofar text-[1px]">אבגדהוזחטיכלמנסעפצקרשת</div>
      
      {/* HEADER CONTAINER - Fixed at top, allows content to flow/collapse */}
      <div ref={headerRef} className="absolute top-0 left-0 w-full z-50 flex flex-col items-center pointer-events-none">
          
          {/* 1. TOP BAR (Fixed, Always Visible) */}
          <div className="w-full relative pointer-events-auto z-20">
              {/* Background Layer with Blur */}
              <div className={`absolute inset-0 ${headerBg} backdrop-blur-md border-b ${borderColor} shadow-sm`} />
              
              {/* Content Layer - No Blur Here to avoid Fixed Position Containing Block issues */}
              <div className={`flex items-center justify-between px-4 h-9 w-full relative`}>
                <div className="flex items-center gap-2 order-2">
                     <div className={`px-3 py-0.5 ${isDark ? 'bg-[#eab308]/10 border-[#eab308]/20 text-[#eab308]' : 'bg-yellow-500/10 border-yellow-500/20 text-yellow-700'} border text-sm font-bold tracking-wide rounded-sm flex items-center gap-2`}>
                        <span className="opacity-100">{getMainTitle()}</span>
                    </div>
                </div>
                <div className="flex items-center gap-2 relative order-1">
                    <button onClick={() => setIsMenuOpen(!isMenuOpen)} className={`w-8 h-8 flex flex-col items-center justify-center gap-[4px] rounded-md transition-colors ${isMenuOpen ? (isDark ? 'bg-white/10' : 'bg-black/10') : hoverBg}`}>
                        <span className={`w-5 h-[2px] ${isDark ? 'bg-white' : 'bg-gray-800'} transition-all ${isMenuOpen ? 'rotate-45 translate-y-[6px]' : ''}`} />
                        <span className={`w-5 h-[2px] ${isDark ? 'bg-white' : 'bg-gray-800'} transition-all ${isMenuOpen ? 'opacity-0' : ''}`} />
                        <span className={`w-5 h-[2px] ${isDark ? 'bg-white' : 'bg-gray-800'} transition-all ${isMenuOpen ? '-rotate-45 -translate-y-[6px]' : ''}`} />
                    </button>

                    {/* Full Screen Toggle Button */}
                    <button 
                        onClick={toggleFullScreen}
                        className={`w-8 h-8 flex items-center justify-center rounded-md transition-colors ${isDark ? 'text-gray-400 hover:text-white hover:bg-white/10' : 'text-gray-600 hover:text-black hover:bg-black/10'}`}
                        title={isFullscreen ? "Exit Full Screen" : "Full Screen"}
                    >
                        {isFullscreen ? (
                             <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                 <path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3" />
                             </svg>
                        ) : (
                             <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                 <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" />
                             </svg>
                        )}
                    </button>
                    
                    {/* 72 Names Button - Only for Boards */}
                    {currentShape === 'boards' && (
                        <button 
                            onClick={() => setShowTripletsModal(true)} 
                            className={`h-8 px-2 flex items-center justify-center rounded-md border transition-colors ${isDark ? 'bg-white/10 border-white/10 text-gray-300 hover:text-white' : 'bg-black/10 border-black/10 text-gray-700 hover:text-black'} font-bold text-xs`}
                            title={t.triplets}
                        >
                            {t.btn72}
                        </button>
                    )}

                    {isMenuOpen && (
                        <>
                            <div 
                                className="fixed inset-0 z-[90]" 
                                onClick={() => setIsMenuOpen(false)} 
                            />
                            <div className={`absolute top-full ${lang === 'he' ? 'right-0' : 'left-0'} mt-2 ${isDark ? 'bg-[#1a1a1a] border-white/20' : 'bg-white border-black/10'} border rounded-lg shadow-[0_10px_40px_rgba(0,0,0,0.2)] w-64 z-[100] overflow-hidden flex flex-col`}>
                                <div className={`p-2 border-b ${borderColor}`}>
                                    <h3 className="text-[10px] uppercase tracking-wider text-gray-500 font-bold px-2 mb-1">{t.menu.mode}</h3>
                                    <div className="flex flex-col gap-1">
                                        {['cube', 'boards', 'sphere', 'stella', 'octahedron', 'dodecahedron', 'icosahedron'].map(s => (
                                            <button key={s} onClick={() => handleSetShape(s as any)} className={`px-3 py-2 text-start rounded ${hoverBg} text-sm ${currentShape===s ? (isDark ? 'text-yellow-400 font-bold bg-white/5' : 'text-yellow-700 font-bold bg-black/5') : (isDark ? 'text-gray-300' : 'text-gray-700')}`}>
                                                {t.shapes[s as keyof typeof t.shapes]}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <div className={`p-2 border-b ${borderColor} ${isDark ? 'bg-[#111]' : 'bg-gray-50'}`}>
                                    <button 
                                        onClick={() => { setTheme(theme === 'dark' ? 'light' : 'dark'); setIsMenuOpen(false); }} 
                                        className={`w-full px-3 py-2 text-start rounded ${hoverBg} text-sm ${isDark ? 'text-gray-300 hover:text-white' : 'text-gray-700 hover:text-black'} flex items-center justify-between`}
                                    >
                                        <span>{t.menu.settings}</span>
                                        {theme === 'dark' ? (
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                <circle cx="12" cy="12" r="5"></circle>
                                                <line x1="12" y1="1" x2="12" y2="3"></line>
                                                <line x1="12" y1="21" x2="12" y2="23"></line>
                                                <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                                                <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                                                <line x1="1" y1="12" x2="3" y2="12"></line>
                                                <line x1="21" y1="12" x2="23" y2="12"></line>
                                                <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                                                <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                                            </svg>
                                        ) : (
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                                            </svg>
                                        )}
                                    </button>
                                </div>
                                <div className={`p-2 ${isDark ? 'bg-[#111]' : 'bg-gray-50'}`}>
                                    <h3 className="text-[10px] uppercase tracking-wider text-gray-500 font-bold px-2 mb-1">{t.menu.info}</h3>
                                    <div className="flex flex-col gap-1">
                                        <button onClick={() => { setShowInfoModal(true); setIsMenuOpen(false); }} className={`px-3 py-2 text-start rounded ${hoverBg} text-sm ${isDark ? 'text-gray-300 hover:text-white' : 'text-gray-700 hover:text-black'}`}>{t.about.title}</button>
                                    </div>
                                </div>
                                <div className={`p-2 border-t ${borderColor} ${isDark ? 'bg-[#111]' : 'bg-gray-50'}`}>
                                    <button onClick={() => setIsLangSubmenuOpen(!isLangSubmenuOpen)} className={`w-full px-3 py-2 text-start rounded text-sm ${isDark ? 'text-gray-300 hover:text-white hover:bg-white/5' : 'text-gray-700 hover:text-black hover:bg-black/5'} flex justify-between items-center group`}>
                                        <span className="font-bold uppercase text-[10px] tracking-wider text-gray-500 group-hover:text-gray-400">{t.menu.language}</span>
                                        <span className={`text-[10px] text-gray-500 transition-transform duration-200 ${isLangSubmenuOpen ? 'rotate-180' : ''}`}>▼</span>
                                    </button>
                                    <div className={`flex flex-col gap-1 ml-3 border-l-2 ${borderColor} pl-2 overflow-hidden transition-all duration-300 ease-in-out ${isLangSubmenuOpen ? 'max-h-[150px] mt-2 opacity-100' : 'max-h-0 mt-0 opacity-0'}`}>
                                        {['he', 'en', 'fr'].map(l => (
                                            <button key={l} onClick={() => { setLang(l as Language); setIsMenuOpen(false); }} className={`px-3 py-2 text-start rounded text-sm transition-colors flex items-center justify-between ${lang === l ? (isDark ? 'text-yellow-400 font-bold bg-white/5' : 'text-yellow-700 font-bold bg-black/5') : (isDark ? 'text-gray-400 hover:text-white hover:bg-white/5' : 'text-gray-600 hover:text-black hover:bg-black/5')}`}>
                                                <span>{l === 'he' ? 'עברית' : l === 'en' ? 'English' : 'Français'}</span>
                                                {lang === l && <span className={isDark ? "text-yellow-400 text-xs" : "text-yellow-600 text-xs"}>●</span>}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </>
                    )}
                </div>
              </div>
          </div>

          {/* 2. STATS PANEL (Collapsible) */}
          <div dir="ltr" className={`w-full overflow-hidden transition-all duration-300 ${headerBg} backdrop-blur-md border-b ${borderColor} shadow-lg flex justify-center pointer-events-auto z-10 ${isStatsPanelVisible && (showStats || currentShape === 'boards') ? 'max-h-[300px] py-1 opacity-100' : 'max-h-0 py-0 opacity-0 border-none'}`}>
             {currentShape === 'boards' ? (
                <div className={`w-full flex flex-col items-center justify-center p-2 text-center ${isDark ? 'text-white' : 'text-gray-900'}`} dir="rtl">
                    <div className="flex items-center gap-4 mb-2">
                         <button onClick={handleNextVerse} className={`${isDark ? 'text-yellow-400 hover:text-white' : 'text-yellow-600 hover:text-black'} text-xl px-2 transition-colors`}>►</button>
                         <span className={`${isDark ? 'text-yellow-400' : 'text-yellow-600'} font-bold font-shofar text-base md:text-lg`}>{versesData[currentVerseIndex].ref}</span>
                         <button onClick={handlePrevVerse} className={`${isDark ? 'text-yellow-400 hover:text-white' : 'text-yellow-600 hover:text-black'} text-xl px-2 transition-colors`}>◄</button>
                    </div>
                    <p className="text-lg md:text-xl font-stam leading-relaxed max-w-4xl px-4">
                        {versesData[currentVerseIndex].text}
                    </p>
                </div>
             ) : (
             <div className={`grid ${(stats.faceBreakdowns.length === 0 && stats.hullPoints === undefined && stats.insideCount === undefined) ? 'grid-cols-[1fr]' : 'grid-cols-[1.2fr_2fr_1fr]'} gap-3 px-3 w-full max-w-6xl ${textColor} text-[10px] font-mono leading-snug`}>
                <div className={`flex flex-col gap-1 ${(stats.faceBreakdowns.length > 0 || stats.hullPoints !== undefined || stats.insideCount !== undefined) ? `border-r ${borderColor}` : ''} px-2 justify-center`}>
                    <div className="flex justify-between items-center"><span className="text-gray-500 text-[10px]">Dims:</span> <span className={`${isDark ? 'text-yellow-400' : 'text-yellow-600'} text-[11px] md:text-xs`} dir="ltr">{stats.dims}</span></div>
                    <div className="flex justify-between items-center"><span className={`${isDark ? 'text-cyan-400' : 'text-cyan-600'} font-bold text-[10px]`}>V:</span> <span className={`${isDark ? 'text-cyan-400' : 'text-cyan-600'} font-bold text-[11px] md:text-xs`}>{fmt(stats.volume)}</span></div>
                    <div className="flex justify-between items-center"><span className={`${isDark ? 'text-emerald-400' : 'text-emerald-600'} font-bold text-[10px]`}>S:</span> <span className={`${isDark ? 'text-emerald-400' : 'text-emerald-600'} font-bold text-[11px] md:text-xs`}>{fmt(stats.surface)}</span></div>
                    <div className="flex justify-between items-center"><span className={`${isDark ? 'text-orange-400' : 'text-orange-600'} font-bold text-[10px]`}>P:</span> <span className={`${isDark ? 'text-orange-400' : 'text-orange-600'} font-bold text-[11px] md:text-xs`}>{stats.points}</span></div>
                </div>
                
                {(stats.faceBreakdowns.length > 0 || stats.hullPoints !== undefined || stats.insideCount !== undefined) && (
                    <div className={`flex flex-col gap-1 border-r ${borderColor} px-2 text-[10px] overflow-hidden`}>
                        {stats.faceBreakdowns.length > 0 ? (
                            <>
                                <div className={`grid grid-cols-5 gap-2 border-b ${borderColor} pb-1 mb-1 font-bold text-gray-500`}>
                                    <span>{t.stats.dimensions}</span>
                                    <span>N</span>
                                    <span>{t.stats.faceArea}</span>
                                    <span>{t.stats.facePoints}</span>
                                    <span>Σ P</span>
                                </div>
                                <div className="flex flex-col gap-1 overflow-y-auto max-h-[100px]">
                                    {stats.faceBreakdowns.map((fb, i) => (
                                        <div key={i} className={`grid grid-cols-5 gap-2 ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                                            <span className="truncate">{fb.latticeDims}</span>
                                            <span>{fb.count}</span>
                                            <span className={`${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>{fb.area}</span>
                                            <span className={`${isDark ? 'text-orange-400' : 'text-orange-600'}`}>{fb.points}</span>
                                            <span className={`${isDark ? 'text-yellow-400' : 'text-yellow-600'}`}>{fb.totalPoints}</span>
                                        </div>
                                    ))}
                                </div>
                            </>
                        ) : (stats.insideCount !== undefined ? (
                            <div className="flex flex-col justify-center h-full gap-1">
                                <div className={`flex justify-between items-center border-b ${borderColor} pb-1`}>
                                    <span className="text-gray-500">{t.stats.totalPoints}</span>
                                    <span className={`${isDark ? 'text-white' : 'text-black'} font-bold`}>{stats.totalGridPoints}</span>
                                </div>
                                <div className="flex justify-between items-center">
                                    <span className="text-gray-500">{t.stats.touching}</span>
                                    <span className="text-blue-400 font-bold">{stats.touchingCount}</span>
                                </div>
                                <div className="flex justify-between items-center">
                                    <span className="text-gray-500">{t.stats.inside}</span>
                                    <span className={`${isDark ? 'text-yellow-400' : 'text-yellow-600'} font-bold`}>{stats.insideCount}</span>
                                </div>
                                <div className="flex justify-between items-center">
                                    <span className="text-gray-500">Outside</span>
                                    <span className="text-gray-500 font-bold">{stats.outsideCount}</span>
                                </div>
                            </div>
                        ) : (
                            <div className="flex items-center justify-center h-full text-gray-500 italic">
                                -
                            </div>
                        ))}
                    </div>
                )}

                {(stats.faceBreakdowns.length > 0 || stats.hullPoints !== undefined) && (
                     <div className="flex flex-col gap-2 justify-center px-2">
                        {stats.faceBreakdowns.length > 0 && (
                            <div className={`flex justify-between items-center border-b ${borderColor} pb-1`}>
                                <span className="text-gray-500 text-[10px] uppercase">{t.stats.faceSum}</span>
                                <span className={`${isDark ? 'text-yellow-400' : 'text-yellow-600'} font-bold text-[11px] md:text-xs`}>{stats.totalFacePoints}</span>
                            </div>
                        )}
                        {stats.hullPoints !== undefined && (
                            <div className="flex justify-between items-center">
                                <span className="text-gray-500 text-[10px] uppercase">{t.stats.hullPoints}</span>
                                <span className="text-pink-400 font-bold text-[11px] md:text-xs">{stats.hullPoints}</span>
                            </div>
                        )}
                     </div>
                )}
            </div>
             )}
          </div>
          
          {/* 3. TOGGLE BUTTON (Hangs below stats, or header if stats closed) */}
          <button 
              onClick={() => setIsStatsPanelVisible(!isStatsPanelVisible)}
              className={`${headerBg} text-gray-400 hover:text-current rounded-b-lg px-6 py-0.5 text-[10px] border-b border-x ${borderColor} shadow-lg transition-colors cursor-pointer flex justify-center items-center pointer-events-auto -mt-[1px] z-0`}
              title={isStatsPanelVisible ? "Hide Stats" : "Show Stats"}
          >
             {isStatsPanelVisible ? '▲' : '▼'}
          </button>
      </div>

      <Canvas 
         shadows 
         dpr={[1, 2]} 
         className="w-full h-full touch-none"
         gl={{ localClippingEnabled: true }}
      >
        {isDark ? <color attach="background" args={['#111']} /> : <color attach="background" args={['#f0f2f5']} />}
        <PerspectiveCamera 
             makeDefault
             position={[30, 30, 30]} 
             fov={fov} 
             near={0.1} 
             far={20000} 
        />
        
        <ZoomFitter 
            splitState={splitState} 
            currentShape={currentShape} 
            viewOrientation={viewOrientation}
            trigger={viewTrigger}
            gapSize={gapSize}
            verticalSpread={verticalSpread}
            isDebugMode={isDebugMode}
            cameraType="perspective"
            fov={fov}
            topOffset={topPanelHeight}
        />
        
        <StableOrbitControls currentShape={currentShape} />

        <ambientLight intensity={isDark ? 0.6 : 1.0} />
        <directionalLight 
            position={[10, 20, 10]} 
            intensity={isDark ? 1.5 : 2.0} 
            castShadow 
            shadow-camera-left={-200}
            shadow-camera-right={200}
            shadow-camera-top={200}
            shadow-camera-bottom={-200}
            shadow-mapSize-width={2048}
            shadow-mapSize-height={2048}
            shadow-bias={-0.0005}
        />
        <directionalLight position={[-10, -10, -5]} intensity={0.5} color={isDark ? "#cae9ff" : "#ffffff"} />
        <Environment preset={isDark ? "warehouse" : "city"} background={false} />

        <Suspense fallback={null}>
          <CubeMatrix 
            cubeColor={cubeColor} 
            splitState={splitState}
            showText={isTextMode}
            isTransparent={isTransparent}
            showLattice={showLatticeInScene} 
            currentShape={currentShape}
            gapSize={gapSize}
            verticalSpread={verticalSpread}
            useMultiColor={useMultiColor}
            fontLoaded={fontLoaded}
            selectedFont={selectedFont}
            isBold={isBold}
            highlightLayer={highlightLayer}
            showHalfStella={showHalfStella}
            theme={theme}
          />
        </Suspense>
      </Canvas>
      
      <div className="absolute bottom-0 left-0 w-full z-40">
        <Controls 
          onCycleColor={handleCycleColor}
          splitState={splitState}
          onSetSplit={(val) => updateSetting('splitState', val)}
          currentShape={currentShape}
          onSetShape={handleSetShape}
          gapSize={gapSize}
          onGapChange={(val) => updateSetting('gapSize', val)}
          verticalSpread={verticalSpread}
          onVerticalSpreadChange={(val) => updateSetting('verticalSpread', val)}
          lang={lang}
          translations={translations}
          useMultiColor={useMultiColor}
          onToggleMultiColor={() => setUseMultiColor(!useMultiColor)}
          onToggleTriplets={() => setShowTripletsModal(true)}
          viewOrientation={viewOrientation}
          onSetViewOrientation={handleSetViewOrientation}
          highlightLayer={highlightLayer}
          onHighlightLayerChange={(val) => updateSetting('highlightLayer', val)}
          showStellaGrid={showStellaGrid}
          onToggleStellaGrid={() => setShowStellaGrid(!showStellaGrid)}
          showHalfStella={showHalfStella}
          onToggleHalfStella={() => setShowHalfStella(!showHalfStella)}
          theme={theme}
        />
      </div>

      {showVersesModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4" onClick={() => setShowVersesModal(false)}>
             <div className="bg-white border border-gray-300 p-6 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto relative shadow-2xl" onClick={(e) => e.stopPropagation()}>
                <button onClick={() => setShowVersesModal(false)} className="absolute top-3 left-3 text-gray-500 hover:text-black text-xl">✕</button>
                <h2 className="text-3xl font-bold mb-2 text-center text-black font-stam">{t.verses}</h2>
                <p className="text-xl text-gray-500 font-bold text-center -mt-1 mb-8">{t.verseSource}</p>
                <div className="flex flex-col gap-8" dir="rtl">
                    {versesData.map((v, i) => (
                        <div key={i}>
                            <h3 className="text-lg font-bold text-gray-700 mb-2">{v.ref}</h3>
                            <p className="text-3xl leading-relaxed text-black font-stam">{v.text}</p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
      )}
      {showFontModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4" onClick={() => setShowFontModal(false)}>
             <div className="bg-[#1a1a1a] border border-white/20 p-4 rounded-lg max-w-[280px] w-full max-h-[90vh] overflow-y-auto relative shadow-2xl" onClick={(e) => e.stopPropagation()}>
                 <button onClick={() => setShowFontModal(false)} className="absolute top-3 left-3 text-gray-400 hover:text-white">✕</button>
                 <h2 className="text-lg font-bold mb-4 text-center text-yellow-400">{t.fontSelect}</h2>
                 <div className="flex items-center justify-between mb-4 px-2 py-2 bg-white/5 rounded border border-white/10">
                      <span className="text-sm text-gray-300">{t.bold}</span>
                      <button onClick={() => setIsBold(!isBold)} className={`w-10 h-5 rounded-full relative transition-colors ${isBold ? 'bg-yellow-500' : 'bg-gray-600'}`}><span className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${isBold ? 'left-6' : 'left-1'}`} /></button>
                 </div>
                 <div className="flex flex-col gap-1" dir="rtl">
                     {AVAILABLE_FONTS.map((font) => (
                         <button key={font.name} onClick={() => { setSelectedFont(font.name); }} className={`p-1.5 rounded flex items-center justify-between transition-colors ${selectedFont === font.name ? 'bg-white/10 border border-yellow-500/50' : 'hover:bg-white/5 border border-transparent'}`}><span className="text-gray-300 text-sm">{font.label}</span><span className="text-xl" style={{ fontFamily: font.name, fontWeight: isBold ? 'bold' : 'normal' }}>אבג</span></button>
                     ))}
                 </div>
             </div>
          </div>
      )}
      {showTripletsModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-2" onClick={() => setShowTripletsModal(false)}>
               <div className="bg-gray-50 border border-gray-200 p-1 rounded-lg max-w-lg w-full relative shadow-2xl" onClick={(e) => e.stopPropagation()}>
                  <button onClick={() => setShowTripletsModal(false)} className="absolute -top-2 -left-2 bg-white rounded-full w-6 h-6 flex items-center justify-center shadow-md border border-gray-200 text-gray-500 hover:text-black text-xs z-10">✕</button>
                  {/* Title removed to save space */}
                  <div className="grid grid-cols-6 gap-1" dir="rtl">
                      {tripletsData.map((item) => (
                          <div key={item.id} className="bg-white border border-gray-200 rounded p-0.5 relative flex flex-col items-center justify-center shadow-sm h-12">
                              <div className="absolute top-0.5 right-1 text-[8px] text-gray-400 leading-none">{item.id}</div>
                              <div className="text-2xl font-stam flex gap-px leading-none mt-1" dir="rtl">
                                  <span style={{ color: '#000040' }}>{item.char1}</span>
                                  <span style={{ color: '#b00000' }}>{item.char2}</span>
                                  <span style={{ color: '#7e22ce' }}>{item.char3}</span>
                              </div>
                          </div>
                      ))}
                  </div>
              </div>
          </div>
      )}
      {showInfoModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4" onClick={() => setShowInfoModal(false)}>
              <div className="bg-[#1a1a1a] border border-white/20 p-6 rounded-lg max-w-lg w-full relative shadow-2xl" onClick={(e) => e.stopPropagation()}>
                  <button onClick={() => setShowInfoModal(false)} className="absolute top-3 left-3 text-gray-400 hover:text-white">✕</button>
                  <div className={lang === 'he' ? 'text-right' : 'text-left'} dir={lang === 'he' ? 'rtl' : 'ltr'}>
                      <h2 className="text-base font-bold mb-4 text-yellow-400">{t.about.title}</h2>
                      <div className="text-gray-300 space-y-4 text-base">
                          <p>{t.about.intro1}</p>
                          <p>{t.about.intro2}</p>
                          <hr className="border-white/10 my-4" />
                          <div>
                              <p className="mb-1">{t.about.consultantTitle}</p>
                              <p className="text-gray-300">{t.about.consultantName}</p>
                              <p className="mt-1">{t.about.bookPrefix} <a href="https://books.apple.com/ca/book/%D7%9E%D7%98%D7%98%D7%A8%D7%95%D7%90%D7%91%D7%9F-%D7%94%D7%A1%D7%A4%D7%99%D7%A8/id1623529555" target="_blank" rel="noreferrer" className="text-yellow-400/80 italic hover:text-yellow-300 hover:underline transition-colors">{t.about.bookTitle}</a></p>
                          </div>
                          <div className="mt-4">
                              <p className="mb-1">{t.about.creatorTitle}</p>
                              <p className="text-gray-300">{t.about.creatorName}</p>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
}
