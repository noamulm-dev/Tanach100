
export const KETUVIM_DATA = {};
