
import { BibleBook, SearchResult, ReaderStyle } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { 
    Loader2, ArrowLeft, ArrowRight, ChevronDown, ChevronUp, CheckCircle2, 
    Book, Scroll, Library, WholeWord, Star,
    History, Trash2, X, Type, Hash, LayoutList, AlignJustify, WrapText, Search
} from 'lucide-react';
import React, { useState, useEffect, useRef, useMemo } from 'react';
import WithHelp from './WithHelp';

interface Props {
    searchQuery: string;
    setSearchQuery: (query: string) => void;
    onSearch: (forceNew?: boolean, queryOverride?: string) => void; 
    searchResults: SearchResult[];
    currentResultIndex: number;
    onPrevious: () => void;
    isSearching: boolean;
    isExpanded: boolean;
    toggleExpanded: () => void;
    searchWholeWord: boolean;
    setSearchWholeWord: (val: boolean) => void;
    searchScope: 'current' | 'torah' | 'tanakh';
    setSearchScope: (scope: 'current' | 'torah' | 'tanakh') => void;
    isDarkMode: boolean;
    readerStyle?: ReaderStyle;
    onStyleChange?: (style: ReaderStyle) => void;
}

const SearchPanel: React.FC<Props> = ({
    searchQuery, setSearchQuery, onSearch, searchResults, currentResultIndex, onPrevious,
    isSearching, searchWholeWord, setSearchWholeWord,
    searchScope, setSearchScope, isDarkMode, readerStyle, onStyleChange,
    isExpanded, toggleExpanded
}) => {
    const { t, dir } = useLanguage();
    const [isIphone, setIsIphone] = useState(false);
    const [isScopeMenuOpen, setIsScopeMenuOpen] = useState(false);
    const [isHistoryOpen, setIsHistoryOpen] = useState(false);
    const [searchHistory, setSearchHistory] = useState<string[]>([]);
    const historyRef = useRef<HTMLDivElement>(null);

    // Initialize history from localStorage with requested defaults
    useEffect(() => {
        const checkIphone = () => {
             const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera;
             if (/iPhone/i.test(userAgent)) {
                 setIsIphone(true);
             }
        };
        checkIphone();

        const savedHistory = localStorage.getItem('bible_search_history');
        let historyData: string[] = [];
        if (savedHistory) {
            try {
                historyData = JSON.parse(savedHistory);
            } catch (e) {
                console.error("Failed to parse search history");
            }
        }
        
        const defaults = [
            "אברהם, יצחק, 1-49",
            "משה , אהרן",
            "קין, הבל, 1, 7",
            "מבול, ארבעים",
            "תורה, יהוה, 14, 49,50", 
            "אלהים, 7, 49, 1", 
            "תורה, יהוה, 48-51",
            "משה , אהרן , 1 ,7",
            "אדמה , צאן, 1, 7"
        ];
        
        let updated = false;
        defaults.slice().reverse().forEach(d => {
            if (!historyData.includes(d)) {
                historyData.unshift(d);
                updated = true;
            }
        });

        if (updated) {
            historyData = historyData.slice(0, 15);
            localStorage.setItem('bible_search_history', JSON.stringify(historyData));
        }
        
        setSearchHistory(historyData);
    }, []);

    const isCurrentQueryStarred = useMemo(() => {
        return searchHistory.includes(searchQuery.trim()) && searchQuery.trim() !== '';
    }, [searchHistory, searchQuery]);

    const toggleStar = (e: React.MouseEvent) => {
        e.stopPropagation();
        const trimmed = searchQuery.trim();
        if (!trimmed) return;

        let newHistory: string[];
        if (isCurrentQueryStarred) {
            newHistory = searchHistory.filter(item => item !== trimmed);
        } else {
            newHistory = [trimmed, ...searchHistory.filter(item => item !== trimmed)].slice(0, 15);
        }
        
        setSearchHistory(newHistory);
        localStorage.setItem('bible_search_history', JSON.stringify(newHistory));
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            e.currentTarget.blur();
            setIsHistoryOpen(false);
            setTimeout(() => {
                onSearch(false, searchQuery);
            }, 50);
        }
    };

    const handleSearchClick = () => {
        setIsHistoryOpen(false);
        onSearch(false, searchQuery);
    };

    const handleHistoryItemClick = (item: string) => {
        setSearchQuery(item);
        setIsHistoryOpen(false);
        onSearch(true, item);
    };

    const clearHistory = (e: React.MouseEvent) => {
        e.stopPropagation();
        setSearchHistory([]);
        localStorage.removeItem('bible_search_history');
    };

    const getScopeIcon = (scope: string) => {
        switch (scope) {
            case 'current': return <Book size={20} />;
            case 'torah': return <Scroll size={20} />;
            case 'tanakh': return <Library size={20} />;
            default: return <Library size={20} />;
        }
    };

    const getScopeLabel = (scope: string) => {
        switch (scope) {
            case 'current': return t('scope_current');
            case 'torah': return t('scope_torah');
            case 'tanakh': return t('scope_tanakh');
            default: return t('scope_tanakh');
        }
    };

    const hasResults = searchResults.length > 0;
    const panelBg = isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200';

    const renderIconToggle = (labelKey: string, icon: React.ReactNode, value: boolean, onChange: (val: boolean) => void) => (
        <WithHelp labelKey={labelKey} position="top">
            <button 
                onClick={() => onChange(!value)}
                className={`flex items-center justify-center w-10 h-10 rounded-xl border-2 transition-all active:scale-95 shrink-0 ${
                    value
                    ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm'
                    : (isDarkMode 
                        ? 'bg-slate-800 border-slate-700 text-slate-500 hover:text-slate-300' 
                        : 'bg-slate-100 border-slate-200 text-slate-500 hover:text-indigo-600')
                }`}
            >
                {icon}
            </button>
        </WithHelp>
    );

    return (
        <div 
            className={`shrink-0 z-50 flex flex-col border-t shadow-[0_-8px_20px_rgba(0,0,0,0.15)] transition-all duration-300 relative ${panelBg}`} 
            dir={dir}
            style={{ paddingBottom: 'calc(0.5rem + env(safe-area-inset-bottom))' }}
        >
            {/* Retractable Handle Button - Pinned to LEFT as requested */}
            <button 
                onClick={toggleExpanded}
                className={`absolute left-4 -top-3 w-12 h-6 flex items-center justify-center rounded-t-xl border-t border-x shadow-sm ${panelBg} text-slate-400 hover:text-indigo-500 transition-colors cursor-pointer`}
                style={{ zIndex: 60 }}
            >
                {isExpanded ? <ChevronDown size={18} strokeWidth={3} /> : <ChevronUp size={18} strokeWidth={3} />}
            </button>

            <div className="px-3 py-2.5 flex flex-col gap-2 relative">
                
                {/* Search History Menu (Above Panel) */}
                {isHistoryOpen && (
                    <>
                        <div className="fixed inset-0 z-10" onClick={() => setIsHistoryOpen(false)}></div>
                        <div 
                            ref={historyRef}
                            className={`absolute bottom-full left-2 right-2 mb-2 z-20 rounded-2xl border shadow-2xl overflow-hidden animate-in slide-in-from-bottom-2 duration-200 ${
                                isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'
                            }`}
                        >
                            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700/50">
                                <span className="text-[11px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">חיפושים שמורים</span>
                                {searchHistory.length > 0 && (
                                    <button onClick={clearHistory} className="text-rose-500 hover:text-rose-400 p-1 transition-colors">
                                        <Trash2 size={16} />
                                    </button>
                                )}
                            </div>
                            <div className="max-h-64 overflow-y-auto custom-scrollbar">
                                {searchHistory.map((item, idx) => (
                                    <button
                                        key={idx}
                                        onClick={() => handleHistoryItemClick(item)}
                                        className={`w-full flex items-center gap-3 px-4 py-3.5 text-base font-bold border-b last:border-0 text-right ${
                                            isDarkMode 
                                            ? 'border-slate-700/50 hover:bg-slate-700 text-slate-100' 
                                            : 'border-slate-100 hover:bg-slate-50 text-slate-900'
                                        }`}
                                    >
                                        <History size={16} className="text-indigo-500 shrink-0" />
                                        <span className="flex-1 truncate">{item}</span>
                                    </button>
                                ))}
                            </div>
                        </div>
                    </>
                )}

                {/* ROW 1: Input and Navigation - Added relative z-30 to stay above history backdrop */}
                <div className="flex items-center gap-2 w-full relative z-30">
                    <div className="relative flex-1 flex items-center">
                        <WithHelp labelKey="label_search_input" position="top" className="w-full">
                            <input
                                type="text"
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                onKeyDown={handleKeyDown}
                                onFocus={() => { if (searchHistory.length > 0) setIsHistoryOpen(true); }}
                                placeholder={t('search_placeholder')}
                                className={`w-full h-11 pl-10 pr-10 rounded-xl border outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-bold ${
                                    isDarkMode 
                                    ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-500' 
                                    : 'bg-slate-50 border-slate-200 text-slate-800 placeholder-slate-400'
                                } ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                            />
                            
                            {/* Star Toggle at the beginning (Right side for RTL) */}
                            <button 
                                onClick={toggleStar}
                                className={`absolute right-3 top-1/2 -translate-y-1/2 p-1.5 rounded-lg transition-all active:scale-90 ${
                                    isCurrentQueryStarred 
                                    ? 'text-amber-500' 
                                    : 'text-slate-400 hover:text-slate-500'
                                }`}
                                title={isCurrentQueryStarred ? "הסר מהשמורים" : "שמור חיפוש"}
                            >
                                <Star size={20} fill={isCurrentQueryStarred ? "currentColor" : "none"} />
                            </button>

                            <button 
                                onClick={() => setIsHistoryOpen(!isHistoryOpen)}
                                className={`absolute left-2 p-1.5 rounded-lg transition-colors ${
                                    isDarkMode ? 'text-slate-300 hover:bg-slate-700' : 'text-slate-500 hover:bg-slate-200'
                                }`}
                            >
                                <History size={20} />
                            </button>
                        </WithHelp>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                        {/* Search button redesigned as a left-pointing arrow with a wide tail containing only the x/y counter */}
                        <WithHelp labelKey="label_search_next" position="top">
                            <button
                                onClick={handleSearchClick}
                                disabled={isSearching}
                                className={`shrink-0 h-11 min-w-[70px] px-3 bg-indigo-600 text-white flex items-center justify-center shadow-lg active:scale-95 transition-all disabled:opacity-50`}
                                style={{ 
                                    clipPath: 'polygon(100% 0%, 15% 0%, 0% 50%, 15% 100%, 100% 100%)',
                                    paddingLeft: '10px' 
                                }}
                            >
                                {isSearching ? (
                                    <Loader2 size={18} className="animate-spin" />
                                ) : (
                                    <div className="font-black text-[14px] tabular-nums tracking-tighter">
                                        {hasResults ? (
                                            `${currentResultIndex + 1}/${searchResults.length}`
                                        ) : (
                                            "0/0"
                                        )}
                                    </div>
                                )}
                            </button>
                        </WithHelp>

                        <WithHelp labelKey="label_search_prev" position="top">
                            <button
                                onClick={onPrevious}
                                disabled={isSearching || !hasResults}
                                className={`shrink-0 w-11 h-11 rounded-xl flex items-center justify-center transition-all active:scale-95 border-2 ${
                                    isDarkMode 
                                    ? 'bg-slate-800 text-slate-100 border-slate-700 disabled:opacity-30' 
                                    : 'bg-slate-100 text-slate-900 border-slate-200 disabled:opacity-30'
                                }`}
                            >
                                {dir === 'rtl' ? <ArrowRight size={20} strokeWidth={3} /> : <ArrowLeft size={20} strokeWidth={3} />}
                            </button>
                        </WithHelp>
                    </div>
                </div>

                {/* ROW 2: Options - Only visible when expanded */}
                {isExpanded && (
                    <div className="flex flex-wrap items-center justify-between gap-3 pt-2 mt-1 border-t border-slate-200/50 dark:border-slate-800/50 animate-in fade-in slide-in-from-top-2 duration-200">
                        {/* Right Side (In RTL, this is the first element) - Scope Selector */}
                        <div className="relative">
                            <button 
                                onClick={() => setIsScopeMenuOpen(!isScopeMenuOpen)}
                                className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-bold transition-all ${
                                    isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-700'
                                }`}
                            >
                                {getScopeIcon(searchScope)}
                                <span className="hidden xs:inline">{getScopeLabel(searchScope)}</span>
                                <ChevronDown size={14} className={`transition-transform ${isScopeMenuOpen ? 'rotate-180' : ''}`} />
                            </button>
                            
                            {isScopeMenuOpen && (
                                <>
                                    <div className="fixed inset-0 z-40" onClick={() => setIsScopeMenuOpen(false)}></div>
                                    <div className={`absolute bottom-full ${dir === 'rtl' ? 'right-0' : 'left-0'} mb-2 z-50 w-40 rounded-xl border shadow-xl overflow-hidden ${
                                        isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'
                                    }`}>
                                        {(['current', 'torah', 'tanakh'] as const).map((s) => (
                                            <button
                                                key={s}
                                                onClick={() => { setSearchScope(s); setIsScopeMenuOpen(false); }}
                                                className={`w-full flex items-center gap-3 px-3 py-2.5 text-xs font-bold transition-colors ${
                                                    searchScope === s 
                                                    ? 'bg-indigo-600 text-white' 
                                                    : (isDarkMode ? 'hover:bg-slate-700 text-slate-300' : 'hover:bg-slate-50 text-slate-700')
                                                }`}
                                            >
                                                {getScopeIcon(s)}
                                                {getScopeLabel(s)}
                                                {searchScope === s && <CheckCircle2 size={14} className="ml-auto" />}
                                            </button>
                                        ))}
                                    </div>
                                </>
                            )}
                        </div>

                        {/* Left Side (In RTL, this is the second element) - Toggles */}
                        <div className="flex items-center gap-2">
                             {/* Whole Word Toggle */}
                             {renderIconToggle('label_whole_words', <WholeWord size={20} />, searchWholeWord, setSearchWholeWord)}
                             
                             {/* Style Toggles (Sync with Reader) */}
                             {readerStyle && onStyleChange && (
                                <div className="flex items-center gap-1 ml-2 border-l pl-2 dark:border-slate-800">
                                    {renderIconToggle('show_nikud', <span className="font-bold text-lg leading-none">אְ</span>, readerStyle.showNikud, (val) => onStyleChange({...readerStyle, showNikud: val}))}
                                    {renderIconToggle('show_verses', <Hash size={18} />, readerStyle.showVerseNumbers, (val) => onStyleChange({...readerStyle, showVerseNumbers: val}))}
                                    {renderIconToggle('show_chapter_headers', <LayoutList size={18} />, !readerStyle.showChapterHeaders, (val) => onStyleChange({...readerStyle, showChapterHeaders: !val}))}
                                    {renderIconToggle('text_align', <AlignJustify size={18} />, readerStyle.textAlign === 'justify', () => onStyleChange({...readerStyle, textAlign: readerStyle.textAlign === 'justify' ? 'right' : 'justify'}))}
                                    {renderIconToggle('text_continuous', <WrapText size={18} />, readerStyle.isContinuous, () => onStyleChange({...readerStyle, isContinuous: !readerStyle.isContinuous}))}
                                </div>
                             )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default SearchPanel;
