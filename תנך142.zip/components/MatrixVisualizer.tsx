
import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { Grid3X3, Loader2, Type, MoveHorizontal, Plus, Minus, Maximize, X } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { SearchResult } from '../types';
import { ELS_COLORS } from './VerseItem';
import { fetchLettersWindow, fetchLettersNext, fetchLettersPrev } from '../services/bibleService';

interface Props {
    searchResults?: SearchResult[];
    activeResult?: SearchResult | null;
    currentContext?: { bookId: string, chapter: number, verse: number };
    onClose: () => void;
    isDarkMode: boolean;
}

interface RawLetter {
    char: string;
    bookId: string;
    chapter: number;
    verse: number;
    letterIdx: number;
}

interface VisualLetter extends RawLetter {
    isMatch: boolean;
    isActive?: boolean;
    color?: string;
    groupId?: number;
    elsSkip?: number;
    matchId?: string;
}

interface ScrollTarget {
    bookId: string;
    chapter: number;
    verse: number;
    letterIdx: number;
    ts: number;
}

const MatrixVisualizer: React.FC<Props> = ({ searchResults, activeResult, currentContext, onClose, isDarkMode }) => {
    const { t } = useLanguage();
    const [letterSize, setLetterSize] = useState(16);
    const spacingFactor = 1.25;
    const cellSize = letterSize * spacingFactor + 1;
    
    const [cols, setCols] = useState(() => {
        const screenWidth = window.innerWidth - 48;
        return Math.max(5, Math.floor(screenWidth / cellSize));
    });

    const [rawLetters, setRawLetters] = useState<RawLetter[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [loadingMessage, setLoadingMessage] = useState('טוען...');
    const [isAppending, setIsAppending] = useState(false);
    const [isPrepending, setIsPrepending] = useState(false);
    const [hasReachedStart, setHasReachedStart] = useState(false);
    
    const [pendingScroll, setPendingScroll] = useState<ScrollTarget | null>(null);

    const containerRef = useRef<HTMLDivElement>(null);
    const [scrollTop, setScrollTop] = useState(0);
    const [containerHeight, setContainerHeight] = useState(0);
    const [fitWidth, setFitWidth] = useState(true);

    const INITIAL_WINDOW_SIZE = 6000;
    const APPEND_SIZE = 3000;

    const visualLetters = useMemo((): VisualLetter[] => {
        if (!rawLetters.length) return [];
        const componentsMap = new Map<string, { groupId: number, text: string, skip: number, matchId: string, isActive: boolean }>();
        
        let activeMatchId = '';
        if (searchResults && activeResult) {
             const idx = searchResults.findIndex(r => 
                 r.bookId === activeResult.bookId && 
                 r.chapter === activeResult.chapter && 
                 r.verse === activeResult.verse && 
                 r.text === activeResult.text
             );
             if (idx !== -1) activeMatchId = `m_${idx}`;
        }

        if (searchResults) {
            searchResults.forEach((res, idx) => {
                if (res?.elsComponents) {
                    const mId = `m_${idx}`;
                    const isResActive = mId === activeMatchId;
                    res.elsComponents.forEach(c => {
                        const key = `${c.bookId}_${c.chapter}_${c.verse}_${c.letterIdx}`;
                        if (isResActive || !componentsMap.has(key) || (componentsMap.get(key)?.isActive === false && isResActive)) {
                            componentsMap.set(key, { groupId: c.groupId, text: res.text, skip: res.elsSkip || 0, matchId: mId, isActive: isResActive });
                        }
                    });
                }
            });
        }

        return rawLetters.map(item => {
            const key = `${item.bookId}_${item.chapter}_${item.verse}_${item.letterIdx}`;
            const meta = componentsMap.get(key);
            let color = undefined;
            if (meta) {
                color = meta.groupId === 99 ? (isDarkMode ? '#fbbf24' : '#d97706') : ELS_COLORS[meta.groupId % ELS_COLORS.length];
            }
            return { ...item, isMatch: !!meta, isActive: meta?.isActive, color, groupId: meta?.groupId, elsSkip: meta?.skip, matchId: meta?.matchId };
        });
    }, [rawLetters, searchResults, activeResult, isDarkMode]);

    const totalRows = Math.ceil(visualLetters.length / cols);
    const totalHeight = totalRows * cellSize;

    const performScroll = useCallback((target: ScrollTarget) => {
        if (!containerRef.current) return;
        
        const idx = rawLetters.findIndex(l => 
            l.bookId === target.bookId && 
            l.chapter === target.chapter && 
            l.verse === target.verse && 
            l.letterIdx === target.letterIdx
        );

        if (idx !== -1) {
            const row = Math.floor(idx / cols);
            const offset = (containerHeight / 2) - (cellSize / 2);
            const topPos = Math.max(0, row * cellSize - offset);
            
            containerRef.current.scrollTo({ top: topPos, behavior: 'auto' });
            setPendingScroll(null);
        }
    }, [rawLetters, cols, cellSize, containerHeight]);

    useEffect(() => {
        if (pendingScroll && !isLoading && rawLetters.length > 0) {
            const timer = setTimeout(() => performScroll(pendingScroll), 50);
            return () => clearTimeout(timer);
        }
    }, [pendingScroll, isLoading, rawLetters.length, performScroll]);

    const loadDataWindow = useCallback(async (target: {bookId: string, chapter: number, verse: number, letterIdx: number}) => {
        setIsLoading(true);
        setLoadingMessage('טוען הקשר...');
        setHasReachedStart(false);
        setRawLetters([]); 

        try {
            const forwardSize = Math.floor(INITIAL_WINDOW_SIZE / 2);
            const forwardLetters = await fetchLettersWindow(target.bookId, target.chapter, target.verse, target.letterIdx, forwardSize);
            
            if (forwardLetters.length === 0) {
                setIsLoading(false);
                return;
            }

            const anchorLetter = forwardLetters[0];
            const backwardLetters = await fetchLettersPrev(anchorLetter, Math.floor(INITIAL_WINDOW_SIZE / 2));
            
            const combinedLetters = [...backwardLetters, ...forwardLetters];
            setRawLetters(combinedLetters);
            
            if (combinedLetters.length > 0 && combinedLetters[0].bookId === 'Genesis' && combinedLetters[0].chapter === 1 && combinedLetters[0].verse === 1 && combinedLetters[0].letterIdx === 0) {
                setHasReachedStart(true);
            }
            
            // Adjust target letter index if we fetched exactly what was requested to ensure scroll works
            // If the exact target letter index is not found (e.g. fetching start of verse), use the first letter of that verse found
            const exactMatch = combinedLetters.find(l => l.bookId === target.bookId && l.chapter === target.chapter && l.verse === target.verse && l.letterIdx === target.letterIdx);
            const scrollTarget = exactMatch ? target : { ...target, letterIdx: forwardLetters[0].letterIdx };

            setPendingScroll({ ...scrollTarget, ts: Date.now() });

        } catch (e) {
            console.error("Matrix load failed", e);
        } finally { 
            setIsLoading(false); 
        }
    }, []);

    // Main Navigation Logic: Unifies "Search Jump" and "Context Switch"
    useEffect(() => {
        if (!currentContext) return;

        // 1. Determine Target Location
        // Default: Start of the current reading context
        let targetLetterIdx = 0;

        // Refine: If active result matches current context, focus on the specific letter
        if (activeResult && activeResult.elsComponents && activeResult.elsComponents.length > 0) {
            const matchStart = activeResult.elsComponents[0];
            if (matchStart.bookId === currentContext.bookId && 
                matchStart.chapter === currentContext.chapter && 
                matchStart.verse === currentContext.verse) {
                targetLetterIdx = matchStart.letterIdx;
            }
        }

        const target = {
            bookId: currentContext.bookId,
            chapter: currentContext.chapter,
            verse: currentContext.verse,
            letterIdx: targetLetterIdx
        };

        // 2. Check if the target exists in current memory
        const inMemoryIdx = rawLetters.findIndex(l => 
            l.bookId === target.bookId && 
            l.chapter === target.chapter && 
            l.verse === target.verse &&
            (l.letterIdx === target.letterIdx || target.letterIdx === 0) // Loose match for verse start
        );

        if (inMemoryIdx !== -1) {
            // Data exists, just scroll to it
            const preciseTarget = { ...target, letterIdx: rawLetters[inMemoryIdx].letterIdx };
            setPendingScroll({ ...preciseTarget, ts: Date.now() });
        } else {
            // Data not in memory (or first load), fetch new window
            loadDataWindow(target);
        }
    }, [currentContext, activeResult, loadDataWindow]); // removed rawLetters from dep to avoid loop

    const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
        const target = e.currentTarget;
        setScrollTop(target.scrollTop);
        
        if (target.scrollHeight - target.scrollTop - target.clientHeight < 1000 && !isAppending && !isLoading && rawLetters.length > 0) {
            setIsAppending(true);
            fetchLettersNext(rawLetters[rawLetters.length - 1], APPEND_SIZE).then(next => {
                if (next.length) setRawLetters(prev => [...prev, ...next]);
                setIsAppending(false);
            });
        }
        
        if (target.scrollTop < 500 && !isPrepending && !isLoading && !hasReachedStart && rawLetters.length > 0) {
            setIsPrepending(true);
            const oldHeight = target.scrollHeight;
            fetchLettersPrev(rawLetters[0], APPEND_SIZE).then(prev => {
                if (prev.length) {
                    setRawLetters(curr => [...prev, ...curr]);
                    setTimeout(() => {
                        if (containerRef.current) {
                            const newHeight = containerRef.current.scrollHeight;
                            containerRef.current.scrollTop += (newHeight - oldHeight);
                        }
                    }, 0);
                    if (prev[0].bookId === 'Genesis' && prev[0].chapter === 1 && prev[0].verse === 1) setHasReachedStart(true);
                } else {
                    setHasReachedStart(true);
                }
                setIsPrepending(false);
            });
        }
    }, [rawLetters, isAppending, isPrepending, isLoading, hasReachedStart]);

    useEffect(() => {
        if (containerRef.current) {
            setContainerHeight(containerRef.current.clientHeight);
            const resizeObs = new ResizeObserver(entries => setContainerHeight(entries[0].contentRect.height));
            resizeObs.observe(containerRef.current);
            return () => resizeObs.disconnect();
        }
    }, []);

    useEffect(() => {
        if (fitWidth && containerRef.current) {
            const w = containerRef.current.clientWidth - 48;
            setCols(Math.max(5, Math.floor(w / cellSize)));
        }
    }, [fitWidth, cellSize]);

    const startRow = Math.max(0, Math.floor(scrollTop / cellSize) - 3);
    const endRow = Math.min(totalRows, Math.ceil((scrollTop + containerHeight) / cellSize) + 3);
    const visibleLetters = visualLetters.slice(startRow * cols, endRow * cols);

    const renderLines = () => {
        const groups: Record<string, { index: number, letter: VisualLetter }[]> = {};
        visualLetters.forEach((l, idx) => {
            if (l.isMatch && l.matchId) {
                if (!groups[l.matchId]) groups[l.matchId] = [];
                groups[l.matchId].push({ index: idx, letter: l });
            }
        });
        const lines: React.ReactNode[] = [];
        Object.entries(groups).forEach(([mId, items]) => {
            if (items.length < 2 || Math.abs(items[0].letter.elsSkip || 0) === 1) return;
            const active = items.some(i => i.letter.isActive);
            items.sort((a, b) => a.index - b.index);
            for (let i = 0; i < items.length - 1; i++) {
                const s = items[i], e = items[i+1];
                const sc = cols - 1 - (s.index % cols), sr = Math.floor(s.index / cols);
                const ec = cols - 1 - (e.index % cols), er = Math.floor(e.index / cols);
                lines.push(<line key={`l-${mId}-${i}`} x1={sc * cellSize + cellSize/2} y1={sr * cellSize + cellSize/2} x2={ec * cellSize + cellSize/2} y2={er * cellSize + cellSize/2} stroke={s.letter.color} strokeWidth={active ? 3 : 2} strokeDasharray={active ? 'none' : '4 3'} opacity={active ? 1 : 0.6} />);
            }
        });
        return lines;
    };

    return (
        <div className="relative w-full h-full flex flex-col overflow-hidden">
            <div className={`shrink-0 h-[40px] border-b flex items-center justify-center gap-2 px-2 backdrop-blur-md z-20 ${isDarkMode ? 'bg-slate-900/50 border-white/5' : 'bg-slate-100/50 border-black/5'}`}>
                <div className="flex items-center gap-1 p-1 bg-indigo-500/10 text-indigo-500 rounded-md"><Grid3X3 size={14} strokeWidth={2.5} /><span className="text-[9px] font-black uppercase ml-1">Matrix</span></div>
                
                {searchResults && activeResult && (
                    <div className="px-2 py-1 bg-indigo-600 text-white text-[10px] font-bold rounded-full">
                        תוצאה {searchResults.indexOf(activeResult) + 1} מתוך {searchResults.length}
                    </div>
                )}

                <div className="flex items-center gap-1 px-1.5 py-1 rounded-lg border bg-white/5 border-current/10">
                    <MoveHorizontal size={12} className="opacity-50" />
                    <button onClick={() => {setFitWidth(false); setCols(Math.max(5, cols - 5));}} className="p-0.5 hover:bg-indigo-500/10 rounded"><Minus size={10}/></button>
                    <span className="text-[10px] font-bold w-5 text-center">{cols}</span>
                    <button onClick={() => {setFitWidth(false); setCols(Math.min(200, cols + 5));}} className="p-0.5 hover:bg-indigo-500/10 rounded"><Plus size={10}/></button>
                </div>
                <button onClick={() => setFitWidth(!fitWidth)} className={`p-1.5 rounded-md ${fitWidth ? 'bg-indigo-600 text-white' : 'hover:bg-white/10 opacity-60'}`}><Maximize size={14} /></button>
                <div className="flex items-center gap-1 px-1.5 py-1 rounded-lg border bg-white/5 border-current/10">
                    <Type size={12} className="opacity-50" />
                    <button onClick={() => setLetterSize(Math.max(8, letterSize - 2))} className="p-0.5 hover:bg-indigo-500/10 rounded"><Minus size={10}/></button>
                    <span className="text-[10px] font-bold w-5 text-center">{letterSize}</span>
                    <button onClick={() => setLetterSize(Math.min(40, letterSize + 2))} className="p-0.5 hover:bg-indigo-500/10 rounded"><Plus size={10}/></button>
                </div>
                <button onClick={onClose} className="p-1.5 bg-rose-500 text-white rounded-md hover:bg-rose-600"><X size={14} strokeWidth={3} /></button>
            </div>

            <div className="flex-1 overflow-auto custom-scrollbar p-6 flex flex-col items-center" ref={containerRef} onScroll={handleScroll}>
                {isLoading ? (
                    <div className="flex flex-col items-center justify-center h-full gap-4 text-slate-400">
                        <Loader2 size={40} className="animate-spin text-indigo-500" />
                        <p className="font-bold">{loadingMessage}</p>
                    </div>
                ) : (
                    <div className="relative" style={{ width: cols * cellSize, height: totalHeight }} dir="rtl">
                        <svg className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-visible z-10">{renderLines()}</svg>
                        
                        <div className="absolute top-0 left-0 w-full h-full" style={{ transform: `translateY(${startRow * cellSize}px)` }}>
                            <div className="grid" style={{ gridTemplateColumns: `repeat(${cols}, ${cellSize}px)`, gridAutoRows: `${cellSize}px` }}>
                                {visibleLetters.map((l, idx) => (
                                    <div key={`${l.bookId}-${l.chapter}-${l.verse}-${l.letterIdx}-${idx}`} className="flex items-center justify-center font-serif font-bold transition-all relative"
                                        style={{ 
                                            width: `${cellSize-1}px`, height: `${cellSize-1}px`, fontSize: `${letterSize}px`,
                                            color: l.isMatch ? 'white' : (isDarkMode ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.2)'),
                                            backgroundColor: l.isMatch ? l.color : 'transparent',
                                            border: l.isActive ? (isDarkMode ? '2px solid #fff' : '2px solid #000') : 'none',
                                            borderRadius: l.isMatch ? '2px' : '0', zIndex: l.isActive ? 10 : 0
                                        }}
                                        title={`${l.bookId} ${l.chapter}:${l.verse}`}
                                    >{l.char}</div>
                                ))}
                            </div>
                        </div>
                        {(isAppending || isPrepending) && (
                            <div className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-indigo-600 text-white px-4 py-2 rounded-full shadow-lg flex items-center gap-2 text-xs font-bold z-50">
                                <Loader2 size={14} className="animate-spin" /> טוען עוד...
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default MatrixVisualizer;
