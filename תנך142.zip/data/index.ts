
export const TANAKH_DATA = {};
