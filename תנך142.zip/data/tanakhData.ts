
// This file is deprecated. Please use data/index.ts which aggregates torah.ts, neviim.ts, and ketuvim.ts.
export const TANAKH_DATA = {};
