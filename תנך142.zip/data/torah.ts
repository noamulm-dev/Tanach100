
export const TORAH_DATA = {};
